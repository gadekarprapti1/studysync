const express = require("express");
const auth    = require("../middleware/auth");

const router = express.Router();
router.use(auth);

// ── POST /api/progress ─────────────────────────────────────────────────────────
router.post("/", (req, res) => {
  const db = req.app.get("db");
  const { task_id, score, notes } = req.body;

  if (!task_id) return res.status(400).json({ error: "task_id is required." });

  const task = db.get(
    "SELECT * FROM tasks WHERE id = ? AND user_id = ?",
    task_id, req.user.id
  );
  if (!task) return res.status(404).json({ error: "Task not found." });

  const numScore = Number(score);
  if (score !== undefined && (isNaN(numScore) || numScore < 0 || numScore > 100)) {
    return res.status(400).json({ error: "Score / Accuracy must be between 0 and 100." });
  }

  // Check if existing progress entry exists, update or insert
  const existing = db.get("SELECT * FROM progress WHERE task_id = ? AND user_id = ?", task_id, req.user.id);
  if (existing) {
    db.run("UPDATE progress SET score = ?, notes = ?, logged_at = datetime('now') WHERE id = ?",
      numScore || 0, notes || existing.notes, existing.id);
  } else {
    db.run(
      "INSERT INTO progress (user_id, task_id, score, notes) VALUES (?, ?, ?, ?)",
      req.user.id, task_id, numScore || 0, notes || null
    );
  }

  // Auto-mark task as completed
  db.run("UPDATE tasks SET status = 'completed' WHERE id = ?", task_id);

  const entry = db.get("SELECT * FROM progress WHERE task_id = ? AND user_id = ?", task_id, req.user.id);
  const updatedTask = db.get("SELECT * FROM tasks WHERE id = ?", task_id);

  res.status(201).json({
    message: "Accuracy score and progress logged successfully.",
    progress: entry,
    task: updatedTask
  });
});

// ── GET /api/progress ──────────────────────────────────────────────────────────
router.get("/", (req, res) => {
  const db = req.app.get("db");
  const logs = db.all(
    `SELECT p.*, t.title as task_title, t.scheduled_date, sp.subject, sp.title as plan_title
     FROM progress p
     JOIN tasks t        ON p.task_id = t.id
     JOIN study_plans sp ON t.plan_id = sp.id
     WHERE p.user_id = ?
     ORDER BY p.logged_at DESC`,
    req.user.id
  );
  res.json({ progress: logs });
});

// ── GET /api/progress/summary ──────────────────────────────────────────────────
router.get("/summary", (req, res) => {
  const db = req.app.get("db");

  const totalTasks     = (db.get("SELECT COUNT(*) as c FROM tasks WHERE user_id = ?", req.user.id) || {}).c || 0;
  const completedTasks = (db.get("SELECT COUNT(*) as c FROM tasks WHERE user_id = ? AND status = 'completed'", req.user.id) || {}).c || 0;
  const pendingTasks   = (db.get("SELECT COUNT(*) as c FROM tasks WHERE user_id = ? AND status = 'pending'", req.user.id) || {}).c || 0;
  
  const avgRow   = db.get("SELECT AVG(score) as avg, COUNT(*) as count FROM progress WHERE user_id = ?", req.user.id);
  const avgScore = avgRow && avgRow.avg ? Math.round(avgRow.avg) : 0;
  const testCount = avgRow ? avgRow.count : 0;

  // Accuracy Segregation
  const highAccuracy = (db.get("SELECT COUNT(*) as c FROM progress WHERE user_id = ? AND score >= 80", req.user.id) || {}).c || 0;
  const medAccuracy  = (db.get("SELECT COUNT(*) as c FROM progress WHERE user_id = ? AND score >= 50 AND score < 80", req.user.id) || {}).c || 0;
  const lowAccuracy  = (db.get("SELECT COUNT(*) as c FROM progress WHERE user_id = ? AND score < 50", req.user.id) || {}).c || 0;

  // Development Stage Calculation
  let devLevel = "Level 1: Foundation Building";
  let devBadge = "🌱 Beginner";
  let devProgress = 25;
  if (completedTasks >= 15 && avgScore >= 80) {
    devLevel = "Level 4: Exam-Ready Master";
    devBadge = "🏆 Top Ranker";
    devProgress = 100;
  } else if (completedTasks >= 8 && avgScore >= 70) {
    devLevel = "Level 3: Proficient Practitioner";
    devBadge = "⚡ Advanced";
    devProgress = 75;
  } else if (completedTasks >= 3) {
    devLevel = "Level 2: Active Problem Solver";
    devBadge = "📈 Progressing";
    devProgress = 50;
  }

  // Subject-wise accuracy breakdown
  const subjectBreakdown = db.all(
    `SELECT sp.subject,
            COUNT(t.id) as total_tasks,
            SUM(CASE WHEN t.status = 'completed' THEN 1 ELSE 0 END) as done_tasks,
            ROUND(AVG(p.score), 1) as avg_accuracy
     FROM study_plans sp
     LEFT JOIN tasks t ON sp.id = t.plan_id
     LEFT JOIN progress p ON t.id = p.task_id
     WHERE sp.user_id = ?
     GROUP BY sp.subject
     ORDER BY done_tasks DESC`,
    req.user.id
  );

  // Recent 5 completions
  const recentLogs = db.all(
    `SELECT p.*, t.title as task_title, sp.subject
     FROM progress p
     JOIN tasks t ON p.task_id = t.id
     JOIN study_plans sp ON t.plan_id = sp.id
     WHERE p.user_id = ?
     ORDER BY p.logged_at DESC
     LIMIT 5`,
    req.user.id
  );

  res.json({
    summary: {
      total_tasks: totalTasks,
      completed_tasks: completedTasks,
      pending_tasks: pendingTasks,
      completion_rate: totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0,
      average_score: avgScore,
      high_accuracy_count: highAccuracy,
      medium_accuracy_count: medAccuracy,
      low_accuracy_count: lowAccuracy,
      development: {
        level: devLevel,
        badge: devBadge,
        progressPercent: devProgress,
        testsLogged: testCount
      },
      subject_breakdown: subjectBreakdown,
      recent_activity: recentLogs
    }
  });
});

// ── GET /api/progress/plan/:planId ─────────────────────────────────────────────
router.get("/plan/:planId", (req, res) => {
  const db = req.app.get("db");
  const plan = db.get(
    "SELECT * FROM study_plans WHERE id = ? AND user_id = ?",
    req.params.planId, req.user.id
  );
  if (!plan) return res.status(404).json({ error: "Study plan not found." });

  const tasks = db.all(
    `SELECT t.*, p.score, p.notes, p.logged_at
     FROM tasks t
     LEFT JOIN progress p ON t.id = p.task_id
     WHERE t.plan_id = ?
     ORDER BY t.scheduled_date ASC`,
    plan.id
  );

  const completed = tasks.filter((t) => t.status === "completed").length;

  res.json({
    plan: plan.title,
    subject: plan.subject,
    total: tasks.length,
    completed,
    completion_rate: tasks.length > 0 ? Math.round((completed / tasks.length) * 100) : 0,
    tasks,
  });
});

module.exports = router;
