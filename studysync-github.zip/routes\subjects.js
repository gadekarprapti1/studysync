const express = require("express");
const auth    = require("../middleware/auth");

const router = express.Router();
router.use(auth);

// ── GET /api/subjects ──────────────────────────────────────────────────────────
// Returns all subjects registered by the student, along with plan & task statistics
router.get("/", (req, res) => {
  const db = req.app.get("db");

  const subjects = db.all(
    `SELECT s.*,
            (SELECT COUNT(*) FROM study_plans sp WHERE sp.user_id = s.user_id AND LOWER(sp.subject) = LOWER(s.name)) as plan_count,
            (SELECT COUNT(*) FROM tasks t JOIN study_plans sp ON t.plan_id = sp.id WHERE t.user_id = s.user_id AND LOWER(sp.subject) = LOWER(s.name)) as task_count,
            (SELECT COUNT(*) FROM tasks t JOIN study_plans sp ON t.plan_id = sp.id WHERE t.user_id = s.user_id AND LOWER(sp.subject) = LOWER(s.name) AND t.status = 'completed') as completed_task_count,
            (SELECT ROUND(AVG(p.score), 1) FROM progress p JOIN tasks t ON p.task_id = t.id JOIN study_plans sp ON t.plan_id = sp.id WHERE p.user_id = s.user_id AND LOWER(sp.subject) = LOWER(s.name)) as avg_accuracy
     FROM user_subjects s
     WHERE s.user_id = ?
     ORDER BY s.created_at ASC`,
    req.user.id
  );

  res.json({
    count: subjects.length,
    hasConfiguredSubjects: subjects.length > 0,
    subjects
  });
});

// ── POST /api/subjects/setup ───────────────────────────────────────────────────
// Bulk setup / onboarding: student specifies how many subjects they have and details
router.post("/setup", (req, res) => {
  const db = req.app.get("db");
  const { subjects, exam } = req.body;

  if (!Array.isArray(subjects) || subjects.length === 0) {
    return res.status(400).json({ error: "Please provide a list of subjects to track." });
  }

  const defaultColors = ["#8b5cf6", "#06b6d4", "#10b981", "#f59e0b", "#ec4899", "#3b82f6", "#84cc16"];
  const created = [];

  subjects.forEach((subj, idx) => {
    const name = typeof subj === "string" ? subj.trim() : (subj.name ? subj.name.trim() : "");
    if (!name) return;

    const targetExam = (subj.target_exam || exam || "GENERAL").toUpperCase();
    const targetScore = Number(subj.target_score) || 90;
    const color = subj.color || defaultColors[idx % defaultColors.length];

    // Check if subject already exists for this user
    const existing = db.get("SELECT * FROM user_subjects WHERE user_id = ? AND LOWER(name) = LOWER(?)", req.user.id, name);
    if (!existing) {
      const result = db.run(
        `INSERT INTO user_subjects (user_id, name, target_exam, target_score, color)
         VALUES (?, ?, ?, ?, ?)`,
        req.user.id, name, targetExam, targetScore, color
      );
      created.push(db.get("SELECT * FROM user_subjects WHERE id = ?", result.lastInsertRowid));
    } else {
      created.push(existing);
    }
  });

  res.status(201).json({
    message: `Successfully configured ${created.length} subjects for your StudySync profile!`,
    totalSubjects: created.length,
    subjects: created
  });
});

// ── POST /api/subjects ─────────────────────────────────────────────────────────
// Add a single subject
router.post("/", (req, res) => {
  const db = req.app.get("db");
  const { name, target_exam, target_score, color } = req.body;

  if (!name || !name.trim()) {
    return res.status(400).json({ error: "Subject name is required." });
  }

  const existing = db.get("SELECT * FROM user_subjects WHERE user_id = ? AND LOWER(name) = LOWER(?)", req.user.id, name.trim());
  if (existing) {
    return res.status(400).json({ error: `Subject '${name.trim()}' is already in your subject roster.` });
  }

  const result = db.run(
    `INSERT INTO user_subjects (user_id, name, target_exam, target_score, color)
     VALUES (?, ?, ?, ?, ?)`,
    req.user.id, name.trim(), (target_exam || "GENERAL").toUpperCase(), Number(target_score) || 90, color || "#8b5cf6"
  );

  const subject = db.get("SELECT * FROM user_subjects WHERE id = ?", result.lastInsertRowid);
  res.status(201).json({ message: "Subject added to your roster.", subject });
});

// ── DELETE /api/subjects/:id ───────────────────────────────────────────────────
router.delete("/:id", (req, res) => {
  const db = req.app.get("db");
  const subject = db.get("SELECT * FROM user_subjects WHERE id = ? AND user_id = ?", req.params.id, req.user.id);
  if (!subject) return res.status(404).json({ error: "Subject not found." });

  db.run("DELETE FROM user_subjects WHERE id = ?", subject.id);
  res.json({ message: `Subject '${subject.name}' removed from your roster.` });
});

module.exports = router;
