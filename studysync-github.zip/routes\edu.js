const express = require("express");
const auth    = require("../middleware/auth");

const router = express.Router();

// ── Trusted Educational Authorities & Verification Sources ──────────────────
const TRUSTED_SOURCES = {
  "NEET": [
    { name: "National Testing Agency (NTA)", type: "Official Exam Body", url: "https://neet.nta.nic.in/", description: "Official NEET examination syllabus, eligibility guidelines & question pattern." },
    { name: "NCERT (National Council of Educational Research & Training)", type: "Primary Textbook Source", url: "https://ncert.nic.in/textbook.php", description: "Standard curriculum and line-by-line textbook reference for Biology, Physics & Chemistry." },
    { name: "National Medical Commission (NMC)", type: "Regulatory Council", url: "https://www.nmc.org.in/", description: "Medical undergraduate curriculum & chapter weightage definitions." },
    { name: "OpenStax & Wikimedia Academic", type: "Peer-Reviewed Open Education", url: "https://openstax.org/subjects/science", description: "Peer-reviewed science concept frameworks and visual biology diagrams." }
  ],
  "NEET-PG": [
    { name: "National Board of Examinations in Medical Sciences (NBEMS)", type: "Official Medical Board", url: "https://natboard.edu.in/", description: "Official NEET-PG / NExT syllabus, clinical case guidelines, and competency benchmarks." },
    { name: "National Medical Commission (NMC CBME)", type: "Curriculum Authority", url: "https://www.nmc.org.in/", description: "Competency-Based Medical Education (CBME) curriculum and clinical blueprints." },
    { name: "PubMed / NIH National Library of Medicine", type: "Medical Research Database", url: "https://pubmed.ncbi.nlm.nih.gov/", description: "Evidence-based medical literature, diagnostic criteria, and clinical trial reviews." }
  ],
  "USMLE": [
    { name: "Federation of State Medical Boards (FSMB) & NBME", type: "Official US Licensing Body", url: "https://www.usmle.org/", description: "Official USMLE Step 1, Step 2 CK content outlines, diagnostic vignettes & practice materials." },
    { name: "First Aid & Pathoma Clinical Frameworks", type: "Standard Reference", url: "https://www.usmle.org/bulletin-information", description: "High-yield organ systems, pharmacology mechanisms, and pathophysiology benchmarks." }
  ],
  "JEE": [
    { name: "NTA JEE Apex Board", type: "Official Exam Body", url: "https://jeemain.nta.nic.in/", description: "Official syllabus blueprint for JEE Main & Advanced mathematics, physics, and chemistry." },
    { name: "IIT JEE Joint Entrance Coordination Board", type: "Official Academic Body", url: "https://jeeadv.ac.in/", description: "Advanced analytical problem specifications and multi-concept guidelines." },
    { name: "NCERT Exemplar Problems", type: "Standard Benchmark", url: "https://ncert.nic.in/exemplar-problems.php", description: "Advanced concept illustrations and numerical problem sets." },
    { name: "MIT OpenCourseWare / Khan Academy STEM", type: "Global Academic Reference", url: "https://ocw.mit.edu/", description: "Foundational STEM lectures and rigorous mathematical proofs." }
  ],
  "MHT-CET": [
    { name: "State Common Entrance Test Cell, Maharashtra", type: "Official Exam Body", url: "https://cetcell.mahacet.org/", description: "Official MHT-CET syllabus, marks distribution (80% Class 12 + 20% Class 11), and guidelines." },
    { name: "Maharashtra State Bureau of Textbook Production (Balbharati)", type: "State Textbook Authority", url: "https://ebalbharati.in/", description: "Maharashtra HSC Board official textbooks for Mathematics, Physics, Chemistry & Biology." },
    { name: "MSBSHSE (Maharashtra State Board)", type: "Education Board", url: "https://www.mahahsscboard.in/", description: "State curriculum objectives, past shift papers, and question banks." }
  ],
  "BITSAT": [
    { name: "BITS Pilani Admissions Division", type: "Official Exam Authority", url: "https://www.bitsadmission.com/", description: "Official BITSAT speed-based examination guidelines, English proficiency and logical reasoning criteria." },
    { name: "NCERT / Advanced Physics & Math Repository", type: "Curriculum Standard", url: "https://ncert.nic.in/", description: "Comprehensive science fundamentals and speed calculation techniques." }
  ],
  "VITEEE": [
    { name: "Vellore Institute of Technology Admissions", type: "Official University Authority", url: "https://viteee.vit.ac.in/", description: "Official VITEEE syllabus for PCM/PCB, English, and Aptitude." },
    { name: "NCERT Higher Secondary Benchmark", type: "Textbook Source", url: "https://ncert.nic.in/", description: "Standard Class 11 & 12 Science curriculum definitions." }
  ],
  "IIT-JAM": [
    { name: "IIT Joint Admission Test for Masters (JAM Portal)", type: "Official IIT Board", url: "https://jam2025.iitd.ac.in/", description: "Official M.Sc. entrance syllabus for Physics, Chemistry, Mathematics, and Biotechnology." },
    { name: "NPTEL / IIT Faculty Repositories", type: "Academic Courseware", url: "https://nptel.ac.in/", description: "Undergraduate core science course lectures and proof frameworks." }
  ],
  "UPSC": [
    { name: "Union Public Service Commission (UPSC)", type: "Constitutional Body", url: "https://upsc.gov.in/", description: "Official Civil Services Examination (CSE) Prelims and Mains syllabus guidelines." },
    { name: "PIB (Press Information Bureau) & PRS India", type: "Official Governance Data", url: "https://pib.gov.in/", description: "Verified government schemes, policy analysis, and legislative research." },
    { name: "NCERT Social Sciences (Class 6-12)", type: "Foundational Benchmark", url: "https://ncert.nic.in/", description: "Core history, geography, polity, and economics conceptual textbooks." }
  ],
  "STATE-PSC": [
    { name: "State Public Service Commissions (MPSC / UPPSC / BPSC / KPSC)", type: "State Constitutional Body", url: "https://mpsc.gov.in/", description: "Official State Civil Services examination syllabus, regional history, geography, and polity." },
    { name: "State Government Gazettes & Budget Reports", type: "Official Governance Records", url: "https://prsindia.org/budgets/states", description: "State budget analysis, socio-economic surveys, and administrative schemes." }
  ],
  "SSC-CGL": [
    { name: "Staff Selection Commission (SSC)", type: "Official Government Exam Board", url: "https://ssc.gov.in/", description: "Official Combined Graduate Level (CGL) Tier-I & Tier-II syllabus, quantitative aptitude & general awareness pattern." },
    { name: "Government of India Official Portals", type: "Statutory Reference", url: "https://www.india.gov.in/", description: "Current government data, cabinet portfolios, constitutional amendments, and economic surveys." }
  ],
  "IBPS-PO": [
    { name: "Institute of Banking Personnel Selection (IBPS)", type: "Official Banking Body", url: "https://www.ibps.in/", description: "Official Probationary Officers (PO) and Clerical common recruitment syllabus and exam structure." },
    { name: "Reserve Bank of India Financial Data", type: "Central Banking Authority", url: "https://www.rbi.org.in/", description: "Monetary policy updates, repo rates, banking terminology, and financial awareness." }
  ],
  "RBI-GRADE-B": [
    { name: "Reserve Bank of India Services Board", type: "Central Bank Board", url: "https://opportunities.rbi.org.in/", description: "Official Grade 'B' Officer syllabus for Economic & Social Issues (ESI), Finance & Management (FM)." },
    { name: "NITI Aayog & Ministry of Finance", type: "Economic Policy Standard", url: "https://www.niti.gov.in/", description: "Macroeconomic reports, financial sector reforms, and sustainable development goals." }
  ],
  "GATE": [
    { name: "GATE National Coordination Board / IITs", type: "Official Examination Body", url: "https://gate2025.iitr.ac.in/", description: "Engineering graduate aptitude test syllabus across specialized engineering disciplines." },
    { name: "NPTEL (National Programme on Technology Enhanced Learning)", type: "IIT Faculty Repository", url: "https://nptel.ac.in/", description: "Peer-reviewed technical courses by IIT professors." }
  ],
  "CAT": [
    { name: "Indian Institutes of Management (IIMs)", type: "Official Management Entrance", url: "https://iimcat.ac.in/", description: "Official syllabus framework for Quantitative Aptitude, DILR, and VARC." },
    { name: "Harvard Business Review & Academic Management Journals", type: "Analytical Standard", url: "https://hbr.org/", description: "Case studies, critical reading, and decision logic frameworks." }
  ],
  "GMAT": [
    { name: "Graduate Management Admission Council (GMAC)", type: "Official Testing Organization", url: "https://www.mba.com/exams/gmat-focus-edition", description: "Official GMAT Focus Edition syllabus: Quantitative, Verbal, and Data Insights sections." },
    { name: "Official Guide for GMAT Review", type: "Benchmark Question Bank", url: "https://www.mba.com/", description: "Standard adaptive reasoning problems and integrated data analysis." }
  ],
  "CA": [
    { name: "Institute of Chartered Accountants of India (ICAI)", type: "Statutory Accounting Body", url: "https://www.icai.org/", description: "Official CA Foundation & Intermediate syllabus, study modules, accounting standards & tax laws." },
    { name: "Ministry of Corporate Affairs (MCA)", type: "Statutory Regulatory Authority", url: "https://www.mca.gov.in/", description: "Companies Act, statutory compliance, corporate reporting and auditing standards." }
  ],
  "CFA": [
    { name: "CFA Institute (Global)", type: "Global Investment Profession Body", url: "https://www.cfainstitute.org/", description: "Official Candidate Body of Knowledge (CBOK), Ethics & Professional Standards, and Asset Valuation." }
  ],
  "CUET": [
    { name: "National Testing Agency (CUET Portal)", type: "Official Exam Body", url: "https://exams.nta.ac.in/CUET-UG/", description: "Central and State Universities Common Entrance Test syllabus." },
    { name: "NCERT Domain Subjects (Class 12)", type: "Prescribed Benchmark", url: "https://ncert.nic.in/", description: "Standard domain subject questions mapped to Class 12 NCERT chapters." }
  ],
  "NDA": [
    { name: "UPSC Defence Examination Branch", type: "Official Exam Authority", url: "https://upsc.gov.in/", description: "National Defence Academy Mathematics and General Ability Test (GAT) syllabus." },
    { name: "Services Selection Board (SSB)", type: "Defence Selection Board", url: "https://joinindianarmy.nic.in/", description: "Officer intelligence rating and physical aptitude guidelines." }
  ],
  "AFCAT": [
    { name: "Indian Air Force (IAF C-DAC Portal)", type: "Air Force Authority", url: "https://afcat.cdac.in/", description: "Official Air Force Common Admission Test syllabus: General Awareness, Verbal Ability, Numerical Ability, Reasoning." }
  ],
  "CLAT": [
    { name: "Consortium of National Law Universities", type: "Official Legal Body", url: "https://consortiumofnlus.ac.in/", description: "Official comprehension-based legal reasoning, logical reasoning, and English syllabus." },
    { name: "Supreme Court of India / LiveLaw", type: "Judicial Precedents Repository", url: "https://main.sci.gov.in/", description: "Landmark constitutional judgments and legal current affairs." }
  ],
  "UGC-NET": [
    { name: "University Grants Commission (UGC) / NTA", type: "National Academic Body", url: "https://ugcnet.nta.ac.in/", description: "Official National Eligibility Test syllabus for Paper-1 (Teaching & Research Aptitude) and Paper-2 Domain." },
    { name: "National Council for Teacher Education (NCTE)", type: "Educational Council", url: "https://ncte.gov.in/", description: "Higher education teaching pedagogy, research ethics, and digital education policies." }
  ],
  "SAT": [
    { name: "College Board (Official SAT)", type: "Official Standardized Testing Organization", url: "https://satsuite.collegeboard.org/", description: "Digital SAT reading, writing, and adaptive mathematics syllabus." },
    { name: "Khan Academy Official SAT Practice", type: "Authorized Preparation Partner", url: "https://www.khanacademy.org/sat", description: "Official practice tests and skill-level diagnostic benchmarks." }
  ],
  "GRE": [
    { name: "ETS (Educational Testing Service)", type: "Official Testing Authority", url: "https://www.ets.org/gre.html", description: "GRE General Test quantitative reasoning, verbal reasoning, and analytical writing criteria." }
  ],
  "IELTS": [
    { name: "British Council & IDP IELTS Official", type: "Official Language Testing System", url: "https://www.ielts.org/", description: "Official IELTS Academic & General Training assessment criteria for Band 7+ to Band 9." },
    { name: "Cambridge English Language Assessment", type: "Curriculum Standard", url: "https://www.cambridgeenglish.org/", description: "Standardized CEFR listening, academic reading passages, task 1 & 2 writing band descriptors." }
  ],
  "TOEFL": [
    { name: "ETS TOEFL iBT Official", type: "Official Testing Organization", url: "https://www.ets.org/toefl.html", description: "Official TOEFL iBT reading, listening, independent & integrated speaking and academic writing criteria." }
  ],
  "BOARD": [
    { name: "Central Board of Secondary Education (CBSE)", type: "National Board Authority", url: "https://www.cbse.gov.in/", description: "Official curriculum guidelines, sample question papers (SQP), and marking schemes." },
    { name: "NCERT Educational Repository", type: "Core Textbook Benchmark", url: "https://ncert.nic.in/", description: "Official textbook derivations, exercises, and conceptual summaries." }
  ],
  "GENERAL": [
    { name: "OpenStax College Repositories", type: "Peer-Reviewed University Curricula", url: "https://openstax.org/", description: "Free, peer-reviewed college textbooks and academic resources." },
    { name: "Wikimedia Foundation / Wikipedia Educational Knowledge", type: "Global Knowledge Base", url: "https://en.wikipedia.org/", description: "Verified encyclopedic overviews, citations, and terminology." }
  ]
};

// ── Exam-Specific Curricula & Strategies ──────────────────────────────────────
const EXAM_PROFILES = {
  "NEET": {
    name: "NEET (UG Medical Entrance - MBBS/BDS)",
    badge: "Medical Entrance",
    category: "Medical",
    subjects: ["Biology", "Physics", "Chemistry"],
    defaultFocus: "NCERT Line-by-Line Mastery & High-Yield MCQs",
    channels: ["Physics Wallah", "Unacademy NEET", "Vedantu BioTronic", "Khan Academy India", "Target NEET"],
    modules: [
      { phase: "Phase 1: Conceptual Foundations & NCERT Reading", title: "NCERT Line-by-Line Deep-Dive & Diagram Recall", priority: "high", durationHours: 3.5, sourceRef: "NCERT Biology/Chemistry Textbook (ncert.nic.in)", desc: "Thoroughly read topic chapters from NCERT. Make active recall notes and practice labeling all diagrams from memory." },
      { phase: "Phase 2: High-Yield Formulas & Mechanism Mastery", title: "Formula Sheet Creation & Concept Derivations", priority: "high", durationHours: 3.0, sourceRef: "NTA NEET Syllabus Guidelines", desc: "Derive key physics formulas, memorize chemistry reaction mechanisms (GOC / Inorganic trends), and build short-notes." },
      { phase: "Phase 3: Topic-wise MCQ Drilling (100+ Questions)", title: "Speed MCQ Practice & Assertion-Reason Questions", priority: "high", durationHours: 4.0, sourceRef: "NTA Question Bank Standards", desc: "Solve 100+ standard MCQs with strict time limits (45 seconds per question). Target high accuracy on assertion-reasoning." },
      { phase: "Phase 4: Previous 10 Years Questions (PYQs) Analysis", title: "Past 10 Years NEET PYQs & Error Log Analysis", priority: "high", durationHours: 3.5, sourceRef: "NTA Past Exam Repository", desc: "Solve all past NEET questions for this chapter. Note down every mistake in your Mistake Notebook for immediate correction." },
      { phase: "Phase 5: Full Mock Simulation & Active Revision", title: "Timed Mock Test & Final NCERT Summary Review", priority: "medium", durationHours: 3.0, sourceRef: "NMC Exam Blueprint", desc: "Simulate a timed chapter mock exam. Review weak areas, NCERT summary points, and formula flashcards." }
    ]
  },
  "NEET-PG": {
    name: "NEET-PG / INI-CET (Doctor of Medicine - MD/MS)",
    badge: "Medical Postgrad",
    category: "Medical",
    subjects: ["Pre-Clinical", "Para-Clinical", "Clinical Specialties"],
    defaultFocus: "Clinical Vignettes, Image-Based MCQs & First Aid Integration",
    channels: ["Marrow", "Prepladder", "Dr. Zainab Vora", "Cerebellum Academy", "Dr. Rohan Khandelwal"],
    modules: [
      { phase: "Phase 1: High-Yield Clinical Theory & 20-Subject Core", title: "Pathology, Pharmacology & Microbiology Clinical Correlates", priority: "high", durationHours: 4.0, sourceRef: "NBEMS NEET-PG Curriculum", desc: "Review disease pathophysiology, drug mechanisms of action, side effects, and histology slides." },
      { phase: "Phase 2: Image-Based Questions (IBQs) & Diagnostic Algorithms", title: "Radiology, Dermatology & Histopathology Image Bank", priority: "high", durationHours: 3.5, sourceRef: "NMC CBME Competency Standards", desc: "Practice 100+ high-yield clinical image questions, CT/MRI interpretations, and ECG rhythm strips." },
      { phase: "Phase 3: Q-Bank Custom Modules & Recent Recall Questions", title: "Timed Clinical Vignette Solving (60 Questions / Hour)", priority: "high", durationHours: 4.0, sourceRef: "Recent INI-CET & NEET-PG Recalls", desc: "Solve case-based multiple choice scenarios focusing on next best step in management." },
      { phase: "Phase 4: Grand Mock Test (200 Questions) & Weak Topic Consolidation", title: "Full-Length 3.5-Hour CBT Simulation & Flashcard Revision", priority: "high", durationHours: 3.5, sourceRef: "NBEMS Exam Pattern", desc: "Analyze strike-rate, percentage accuracy in clinical medicine vs basic sciences, and revise Anki flashcards." }
    ]
  },
  "USMLE": {
    name: "USMLE (United States Medical Licensing Exam - Step 1/2)",
    badge: "US Medical Licensing",
    category: "Medical",
    subjects: ["Pathology", "Physiology", "Pharmacology", "Biochemistry", "Microbiology", "Clinical Medicine"],
    defaultFocus: "UWorld QBank, First Aid Mapping & Pathoma Intuition",
    channels: ["Boards and Beyond", "Pathoma", "Sketchy Medical", "Dirty Medicine", "Ninja Nerd"],
    modules: [
      { phase: "Phase 1: Organ System Foundation & First Aid Annotations", title: "Pathophysiology & Mechanism Mastery", priority: "high", durationHours: 4.0, sourceRef: "USMLE Content Outline (usmle.org)", desc: "Systematic review of First Aid organ chapters with deep conceptual pathophysiology." },
      { phase: "Phase 2: UWorld Question Bank (Timed & Random Blocks)", title: "40-Question Timed Block & Comprehensive Explanations", priority: "high", durationHours: 4.5, sourceRef: "NBME Assessment Standards", desc: "Tackle 2 blocks of 40 multi-step diagnostic questions. Read all incorrect answer explanations." },
      { phase: "Phase 3: NBME Practice Exams & Score Predictor Review", title: "NBME Form Simulation & High-Yield Weak Area Drilling", priority: "high", durationHours: 3.5, sourceRef: "NBME Self-Assessment Portal", desc: "Identify diagnostic blind spots, pharma side-effects, and statistical biostatistics calculations." }
    ]
  },
  "JEE": {
    name: "JEE (Main & Advanced - Engineering)",
    badge: "Engineering Entrance",
    category: "Engineering",
    subjects: ["Mathematics", "Physics", "Chemistry"],
    defaultFocus: "Concept Depth, Multi-Concept Problems & PYQs",
    channels: ["MathonGo", "Physics Galaxy", "Unacademy JEE", "Mohit Tyagi (Competishun)", "JEE Wallah"],
    modules: [
      { phase: "Phase 1: Deep Theory & Rigorous Foundations", title: "Mathematical Foundations, Proofs & Core Concepts", priority: "high", durationHours: 4.0, sourceRef: "IIT JEE Advanced Syllabus Guidelines", desc: "Master mathematical definitions, coordinate visualizations, vectors, and physical laws from first principles." },
      { phase: "Phase 2: Standard Problem Solving & Formula Application", title: "Level 1 Problem Sets & Core Numerical Methods", priority: "medium", durationHours: 3.5, sourceRef: "NCERT Exemplar & Standard Engineering Benchmarks", desc: "Solve 40-50 standard problems to establish solid calculation speed and direct formula application habits." },
      { phase: "Phase 3: JEE Main PYQ Marathon (2019–2025)", title: "Recent 5 Years Shift PYQs Solving", priority: "high", durationHours: 4.5, sourceRef: "NTA JEE Main Official Shift Papers", desc: "Solve all recent shift questions under timed conditions. Learn pattern traps and optimal question selection." },
      { phase: "Phase 4: Advanced Multi-Concept & Tough Problem Set", title: "Multi-Topic Synthesis & JEE Advanced Level Problems", priority: "high", durationHours: 4.0, sourceRef: "JEE Advanced Benchmark Problem Bank", desc: "Tackle multi-concept questions that combine two or more chapters into single complex problems." },
      { phase: "Phase 5: Computer-Based Test (CBT) Simulation & Speed Drill", title: "Timed Mock Drill & Negative Marking Optimization", priority: "high", durationHours: 3.5, sourceRef: "NTA CBT Mock Guidelines", desc: "Simulate exact CBT interface timing. Practice strategic skips to minimize negative marks." }
    ]
  },
  "MHT-CET": {
    name: "MHT-CET (Maharashtra Common Entrance Test)",
    badge: "State Level Entrance",
    category: "Engineering / Medical",
    subjects: ["Mathematics", "Physics", "Chemistry", "Biology"],
    defaultFocus: "Maharashtra State Board Textbook & Fast MCQ Solving",
    channels: ["Dinesh Sir Smart Study", "Mukesh Sir Physics", "Sovind Sir Chemistry", "New Indian Era (NIE)", "Gyan Lab"],
    modules: [
      { phase: "Phase 1: Maharashtra State Board Textbook Line-by-Line", title: "Balbharati HSC Textbook Study & Solved Examples", priority: "high", durationHours: 3.5, sourceRef: "Balbharati Maharashtra HSC Board (ebalbharati.in)", desc: "Study Class 12 (80% weightage) + Class 11 (20% weightage) State Board textbook chapters and memorize all definitions." },
      { phase: "Phase 2: Shortcut Formula Tricks & Speed Drills", title: "Formula Memorization & 60-Second Solving Shortcuts", priority: "high", durationHours: 3.0, sourceRef: "MHT-CET State CET Cell Exam Blueprint", desc: "Master calculation shortcuts, elimination techniques, and formula substitution tricks for rapid MCQ solving." },
      { phase: "Phase 3: Chapter-Wise MHT-CET PYQs (Past 5 Years)", title: "All Shift Papers PYQs Drilling (2020–2025)", priority: "high", durationHours: 4.0, sourceRef: "Maharashtra State CET Cell Past Papers", desc: "Solve previous 5 years MHT-CET questions across all PCM/PCB shifts to understand recurring question types." },
      { phase: "Phase 4: Speed Booster Drills (No Negative Marking)", title: "Speed Accuracy Drills & High-Attempt Strategy", priority: "high", durationHours: 3.5, sourceRef: "State CET Cell Exam Guidelines", desc: "Maximize total attempted questions within 90 minutes per section leveraging the no negative marking rule." },
      { phase: "Phase 5: Full Mock Test & Score Optimization", title: "150-Minute Full-Length Mock Simulation & Revision", priority: "medium", durationHours: 3.0, sourceRef: "MSBSHSE Curriculum Standards", desc: "Complete a full timed mock test, analyze mistakes, and revise high-yield formula sheets." }
    ]
  },
  "BITSAT": {
    name: "BITSAT (Birla Institute of Technology and Science)",
    badge: "Engineering & Science",
    category: "Engineering",
    subjects: ["Physics", "Chemistry", "Mathematics", "English & Logical Reasoning"],
    defaultFocus: "High Speed Accuracy (130 Questions in 180 Mins) & Bonus Questions",
    channels: ["MathonGo BITSAT", "Physics Wallah BITSAT", "Unacademy BITSAT", "Competishun"],
    modules: [
      { phase: "Phase 1: NCERT Fundamentals & Core Formulas", title: "Rapid Theory Review & Formula Memorization", priority: "high", durationHours: 3.0, sourceRef: "BITS Pilani Syllabus Framework", desc: "Speed review of foundational physics, chemistry, and mathematics formulas with zero calculation delay." },
      { phase: "Phase 2: Speed Drills (Under 75 Seconds per Question)", title: "Direct Numerical & Conceptual MCQ Drills", priority: "high", durationHours: 3.5, sourceRef: "BITSAT Standard Mock Test Series", desc: "Practice high-velocity solving targeting 130 questions in 180 minutes with minimal rough-work overhead." },
      { phase: "Phase 3: English Proficiency & Logical Reasoning Practice", title: "Vocabulary, Grammar, Syllogisms & Series", priority: "high", durationHours: 2.5, sourceRef: "BITSAT English & Logic Guidelines", desc: "Solve 25+ logic reasoning questions, verbal analogies, and sentence correction passages." },
      { phase: "Phase 4: Full-Length Speed Simulation & Bonus Questions Strategy", title: "130-Question Full Test & 12 Bonus Questions Drill", priority: "high", durationHours: 3.5, sourceRef: "BITS Admissions Division Practice Papers", desc: "Simulate test conditions and practice finishing all 130 questions early to unlock 12 bonus questions." }
    ]
  },
  "VITEEE": {
    name: "VITEEE & COMEDK (Top Tech & Private Engineering)",
    badge: "Engineering Entrance",
    category: "Engineering",
    subjects: ["Mathematics/Biology", "Physics", "Chemistry", "Aptitude", "English"],
    defaultFocus: "Speed Solving, Aptitude Shortcuts & No Negative Marking",
    channels: ["Vedantu JEE", "Physics Wallah", "Unacademy JEE", "Career360 Prep"],
    modules: [
      { phase: "Phase 1: High-Speed Science Theory & Formula Application", title: "Class 11 & 12 Physics, Chem & Math Formula Sheets", priority: "high", durationHours: 3.0, sourceRef: "VIT Admissions Blueprint", desc: "Review rapid problem-solving tricks across Mechanics, Calculus, and Organic Chemistry." },
      { phase: "Phase 2: Aptitude & English Speed Drills", title: "Data Interpretation, Syllogisms & Grammar", priority: "high", durationHours: 2.5, sourceRef: "VITEEE Aptitude Syllabus", desc: "Practice solving 10 aptitude and 5 English questions in under 12 minutes." },
      { phase: "Phase 3: Full 125-Question CBT Simulation", title: "150-Minute Speed CBT Mock Exam", priority: "high", durationHours: 3.0, sourceRef: "VITEEE Mock Test Interface", desc: "Aim for 110+ attempts with zero negative marking penalty." }
    ]
  },
  "IIT-JAM": {
    name: "IIT-JAM (Joint Admission Test for M.Sc. at IITs/IISc)",
    badge: "M.Sc. Entrance",
    category: "Engineering / Science",
    subjects: ["Physics", "Chemistry", "Mathematics", "Biotechnology"],
    defaultFocus: "Graduation-Level Problem Solving, MSQs & NAT Precision",
    channels: ["Physics by Fiziks", "Chem Academy", "Dips Academy", "NPTEL IIT Courses"],
    modules: [
      { phase: "Phase 1: B.Sc. Advanced Theory & Rigorous Derivations", title: "Linear Algebra, Quantum Mechanics, Physical Chemistry", priority: "high", durationHours: 4.0, sourceRef: "IIT JAM Official Syllabus (iitd.ac.in)", desc: "Build thorough mathematical derivations and undergraduate conceptual rigor." },
      { phase: "Phase 2: Multiple Select Questions (MSQ) & NAT Practice", title: "Multi-Option Logical Solving & Virtual Calculator", priority: "high", durationHours: 3.5, sourceRef: "IIT Organizing Institute Papers", desc: "Master MSQ question tricks where all correct options must be identified." },
      { phase: "Phase 3: Past 10 Years IIT JAM Papers Solving", title: "All Shift PYQ In-Depth Solutions & Mistake Log", priority: "high", durationHours: 4.0, sourceRef: "IIT JAM Archive", desc: "Complete 60-question 100-mark mock papers with strict timing." }
    ]
  },
  "SSC-CGL": {
    name: "SSC CGL (Staff Selection Commission - Officers & Inspectors)",
    badge: "Government Exam",
    category: "Government Jobs",
    subjects: ["Quantitative Aptitude", "General Intelligence & Reasoning", "English Language", "General Awareness"],
    defaultFocus: "Speed Math (Arithmetic/Advance), Tier-1 & Tier-2 Computer-Based Mastery",
    channels: ["Gagan Pratap Maths", "Aditya Ranjan Talks", "Abhinay Maths", "RBE Revolution Education", "Adda247 SSC"],
    modules: [
      { phase: "Phase 1: Advance Math & Arithmetic Shortcuts", title: "Geometry, Mensuration, Algebra & Fast Calculation Tricks", priority: "high", durationHours: 4.0, sourceRef: "SSC Official Syllabus (ssc.gov.in)", desc: "Master digital sum, unit digit methods, Pythagorean triplets, and algebraic formulas for 30-second solving." },
      { phase: "Phase 2: General Awareness (Static GK + Science + Current Affairs)", title: "Polity Articles, History Timelines, Geography & Monthly GK", priority: "high", durationHours: 3.0, sourceRef: "Government of India Official Portals", desc: "Revise constitutional amendments, classical dances, national parks, and past 12 months current affairs." },
      { phase: "Phase 3: Reasoning & English Spotting Errors / Comprehension", title: "Coding-Decoding, Analogies, Vocab & Cloze Tests", priority: "high", durationHours: 3.5, sourceRef: "SSC Past Exam Question Repository", desc: "Solve 50 reasoning questions and 50 English comprehension passages with target 95%+ accuracy." },
      { phase: "Phase 4: Tier-1 & Tier-2 Timed Mock Test Marathon", title: "100-Question 60-Minute Speed CBT Simulation", priority: "high", durationHours: 3.5, sourceRef: "SSC CGL CBT Test Series", desc: "Target 160+ raw score in Tier-1 and practice sectional timing for Tier-2 mathematical abilities." }
    ]
  },
  "IBPS-PO": {
    name: "IBPS & SBI PO (Banking Probationary Officer)",
    badge: "Banking Entrance",
    category: "Banking / Finance",
    subjects: ["Quantitative Aptitude (Data Analysis)", "Reasoning Ability (Puzzles/Seating)", "English Language", "General & Financial Awareness"],
    defaultFocus: "High-Level Puzzles, DI Caselets & Speed Arithmetic",
    channels: ["Bankers Way", "Adda247 Banking", "Oliveboard", "Unacademy Banking", "StudyIQ Bank"],
    modules: [
      { phase: "Phase 1: High-Velocity Speed Math & Simplification", title: "Approximation, Number Series & Quadratic Equations", priority: "high", durationHours: 3.0, sourceRef: "IBPS PO Official Blueprint (ibps.in)", desc: "Master mental math tricks to secure 10-15 marks in under 5 minutes in Prelims." },
      { phase: "Phase 2: High-Level Reasoning Puzzles & Seating Arrangements", title: "Floor, Box, Circular & Variable-Based Complex Puzzles", priority: "high", durationHours: 4.0, sourceRef: "SBI/IBPS Mains Puzzle Archive", desc: "Solve 5 new high-difficulty puzzle sets daily with zero deadlocks." },
      { phase: "Phase 3: Advanced Data Interpretation & Caselets (DI/DA)", title: "Radar, Pie-Chart, Bar Graph & Missing DI Caselets", priority: "high", durationHours: 3.5, sourceRef: "Banking Mains Examination Standards", desc: "Master calculation-heavy multi-layered DI sets required for SBI & IBPS Mains." },
      { phase: "Phase 4: Banking & Financial Awareness (RBI Bulletins)", title: "Monetary Policy, Capital Markets, Banking Terms & Current Affairs", priority: "medium", durationHours: 2.5, sourceRef: "RBI Official Financial Bulletins", desc: "Study priority sector lending, Basel III norms, repo rates, and banking awareness." },
      { phase: "Phase 5: Prelims & Mains Full-Length Speed Mocks", title: "20-Minute Sectional Timed Prelims & Mains CBT", priority: "high", durationHours: 3.5, sourceRef: "National Banking Mock Series", desc: "Simulate test conditions and optimize question selection order." }
    ]
  },
  "RBI-GRADE-B": {
    name: "RBI Grade B (Reserve Bank of India Officers)",
    badge: "Central Banking",
    category: "Banking / Finance",
    subjects: ["Phase 1 (General Awareness, Quant, Reasoning, English)", "Phase 2 (Economic & Social Issues - ESI)", "Phase 2 (Finance & Management - FM)"],
    defaultFocus: "Macroeconomics, RBI Reports & Descriptive Answer Writing",
    channels: ["Edutap RBI Grade B", "Anuj Jindal", "AffairsCloud", "Brajesh Mohan"],
    modules: [
      { phase: "Phase 1: General Awareness & Financial Current Affairs", title: "Banking Current Affairs, Union Budget & Economic Survey", priority: "high", durationHours: 3.5, sourceRef: "RBI Services Board Syllabus", desc: "Master 80-mark GA section with deep coverage of government schemes and RBI circulars." },
      { phase: "Phase 2: Economic & Social Issues (ESI) Deep Dive", title: "Inflation, Growth Models, Monetary Policy & Social Sectors", priority: "high", durationHours: 4.0, sourceRef: "NITI Aayog & Ministry of Finance Reports", desc: "Study macroeconomic indicators, poverty alleviation, and international financial institutions." },
      { phase: "Phase 3: Finance & Management (FM) Conceptual Frameworks", title: "Financial Systems, Corporate Governance, Leadership Theories", priority: "high", durationHours: 3.5, sourceRef: "RBI Management Curriculum", desc: "Master financial derivatives, ratio analysis, and organizational behavior." },
      { phase: "Phase 4: Descriptive Answer Writing & Keyboard Typing Practice", title: "Structured 15-Mark Descriptive ESI & FM Answers", priority: "high", durationHours: 3.0, sourceRef: "RBI Phase 2 Exam Pattern", desc: "Practice typing structured answers with introduction, data, and policy recommendations." }
    ]
  },
  "UPSC": {
    name: "UPSC CSE (Civil Services Exam - IAS/IPS)",
    badge: "Civil Services",
    category: "Civil Services",
    subjects: ["General Studies", "History", "Polity", "Geography", "Economy", "CSAT"],
    defaultFocus: "Conceptual Clarity, Multi-Disciplinary Linkage & Mains Answer Writing",
    channels: ["StudyIQ IAS", "Drishti IAS", "Unacademy UPSC", "Sleepy Classes", "Vision IAS"],
    modules: [
      { phase: "Phase 1: NCERT Standard Book Foundations (Class 6-12)", title: "Core Conceptual Foundations & Historical/Polity Context", priority: "high", durationHours: 4.0, sourceRef: "NCERT Social Sciences & UPSC Syllabus", desc: "Read foundational texts (Polity by Laxmikanth, Modern History by Spectrum, Geography NCERTs)." },
      { phase: "Phase 2: Current Affairs & Policy Integration (The Hindu / PIB)", title: "Dynamic Linking with Schemes, Supreme Court Judgments & Budget", priority: "high", durationHours: 3.5, sourceRef: "PIB & PRS Legislative Research", desc: "Connect textbook theory to current national governance, environmental treaties, and economic indices." },
      { phase: "Phase 3: Prelims Previous Year Questions (PYQs 2013–2025)", title: "Elimination Techniques & Statement Analysis", priority: "high", durationHours: 4.0, sourceRef: "UPSC Official Prelims Archive", desc: "Solve past 10 years Prelims GS Paper 1 & CSAT questions. Practice elimination logic on multiple-statement questions." },
      { phase: "Phase 4: Mains Answer Writing & Diagrammatic Representation", title: "Structured GS Answer Writing (Intro-Body-Conclusion)", priority: "high", durationHours: 3.5, sourceRef: "UPSC Mains Evaluated Benchmarks", desc: "Write 5 answers daily with flowchart diagrams, constitutional articles, and committee recommendations." }
    ]
  },
  "STATE-PSC": {
    name: "State PSC (MPSC / UPPSC / BPSC / KPSC Civil Services)",
    badge: "State Civil Services",
    category: "Civil Services",
    subjects: ["State Specific GK & Geography", "General Studies (History, Polity, Economy)", "CSAT & State Language"],
    defaultFocus: "State Culture, Regional Geography, Local Administration & GS",
    channels: ["StudyIQ State PSC", "Unacademy State PSC", "Drishti State PCS", "Utkarsh Classes"],
    modules: [
      { phase: "Phase 1: State History, Geography, Culture & Administration", title: "Regional Heritage, Districts, Rivers, Agriculture & Policies", priority: "high", durationHours: 3.5, sourceRef: "State PSC Official Syllabus (mpsc.gov.in)", desc: "Master state-specific geography, local dynasties, tribal culture, and state government schemes." },
      { phase: "Phase 2: General Studies (Polity, History, Economy) Core Alignment", title: "Constitutional Provisions & State Economy Budget", priority: "high", durationHours: 3.5, sourceRef: "State Budget Reports & NCERT", desc: "Connect national syllabus with state-level administrative implications." },
      { phase: "Phase 3: State PSC Prelims Past 10 Years Question Solving", title: "Shift-wise State PSC PYQ Drilling & Negative Marking Strategy", priority: "high", durationHours: 4.0, sourceRef: "State PSC Official Papers", desc: "Solve all past state examination papers to recognize state-specific repeating question patterns." },
      { phase: "Phase 4: State Language & Descriptive Mains Answer Writing", title: "Regional Language Essay & GS Descriptive Paper Practice", priority: "high", durationHours: 3.0, sourceRef: "State Commission Mains Pattern", desc: "Practice state official language grammar and structured answer writing." }
    ]
  },
  "GATE": {
    name: "GATE (Graduate Aptitude Test in Engineering)",
    badge: "Graduate Engineering / PSU",
    category: "Engineering / Masters",
    subjects: ["Engineering Mathematics", "General Aptitude", "Core Engineering Discipline"],
    defaultFocus: "Numerical Answer Type (NAT) Questions & Mathematical Rigor",
    channels: ["Gate Wallah", "Unacademy GATE", "Made Easy", "NPTEL IIT Courses", "Gate Smashers"],
    modules: [
      { phase: "Phase 1: Core Technical Foundations & Theorems", title: "Standard Textbook Derivations & System Logic", priority: "high", durationHours: 4.0, sourceRef: "GATE National Coordination Board Blueprint", desc: "Master core departmental subjects and Engineering Mathematics matrices, calculus, and probability." },
      { phase: "Phase 2: Numerical Answer Type (NAT) & Virtual Calculator Practice", title: "Calculation Precision & Error-Free NAT Practice", priority: "high", durationHours: 3.5, sourceRef: "Official GATE Virtual Calculator Interface", desc: "Solve non-MCQ numerical problems using only the onscreen virtual calculator to eliminate arithmetic errors." },
      { phase: "Phase 3: Previous 20 Years GATE Question Drilling", title: "Topic-wise Past 20 Years Papers Solving", priority: "high", durationHours: 4.5, sourceRef: "IIT GATE Past Exam Archive", desc: "Deep dive into recurring core engineering problems, circuit analysis, algorithms, and thermo cycles." },
      { phase: "Phase 4: Subject-wise & Full-Length Test Series", title: "65 Questions / 3-Hour Timed CBT Simulation", priority: "high", durationHours: 3.5, sourceRef: "IIT Organizing Institute Mock Test", desc: "Simulate 100-mark full test and analyze precision in Technical (70) + Math (15) + Aptitude (15)." }
    ]
  },
  "CAT": {
    name: "CAT (Common Admission Test - IIMs / MBA)",
    badge: "Management Entrance",
    category: "Management",
    subjects: ["Quantitative Aptitude (QA)", "Data Interpretation & Logical Reasoning (DILR)", "Verbal Ability & Reading Comprehension (VARC)"],
    defaultFocus: "Set Selection, Reading Speed & Question Elimination",
    channels: ["Rodha", "2IIM CAT Prep", "Unacademy CAT", "Elites Grid", "Cracku"],
    modules: [
      { phase: "Phase 1: Arithmetic & Algebra Fundamentals / Daily RC Reading", title: "Core Math Shortcuts & 4 Daily RC Editorial Passages", priority: "high", durationHours: 3.5, sourceRef: "IIM CAT Syllabus Blueprint", desc: "Master percentages, ratios, modern math, and read Aeon/The Economist essays for reading comprehension." },
      { phase: "Phase 2: DILR Puzzle Sets & Caselet Solving", title: "Arrangements, Matrix Grids, Games & Tournaments", priority: "high", durationHours: 3.5, sourceRef: "CAT Past DILR Archive", desc: "Solve 4-5 diverse DILR sets daily. Focus on set selection: identifying solvable vs trap sets." },
      { phase: "Phase 3: Topic-wise Timed Sectionals & Past 5 Years Shift Papers", title: "66-Question Timed Sectional Tests (40 Mins Each)", priority: "high", durationHours: 4.0, sourceRef: "IIM Past Shift Question Papers", desc: "Practice strict 40-minute sectional limits. Focus on accuracy over mindless attempts." },
      { phase: "Phase 4: Full-Length Proctored Mock Test & Percentile Analysis", title: "2-Hour Full Mock Simulation & In-depth Review", priority: "high", durationHours: 3.5, sourceRef: "National MBA Mock Percentile Benchmarks", desc: "Review every unanswered and wrong question to identify decision blindspots." }
    ]
  },
  "GMAT": {
    name: "GMAT Focus Edition (Global MBA Admissions)",
    badge: "Global MBA",
    category: "Management",
    subjects: ["Quantitative Reasoning", "Verbal Reasoning", "Data Insights"],
    defaultFocus: "Data Insights Tables/Graphs, Critical Reasoning & Precision Math",
    channels: ["GMAT Club", "Magoosh GMAT", "Manhattan Prep", "Target Test Prep"],
    modules: [
      { phase: "Phase 1: Data Insights & Multi-Source Reasoning", title: "Table Analysis, Graphics Interpretation & Two-Part Analysis", priority: "high", durationHours: 3.5, sourceRef: "GMAC GMAT Focus Blueprint", desc: "Master spreadsheet data interpretation, multi-source reasoning tabs, and data sufficiency." },
      { phase: "Phase 2: Critical Reasoning Arguments & Reading Comprehension", title: "Strengthen, Weaken, Assumption & Flaw Logic", priority: "high", durationHours: 3.5, sourceRef: "Official Guide for GMAT", desc: "Break down complex arguments into premise and conclusion with zero assumption bias." },
      { phase: "Phase 3: Quantitative Reasoning (Pure Problem Solving)", title: "Number Theory, Algebra, Word Problems (No Calculator)", priority: "high", durationHours: 3.0, sourceRef: "GMAC Official Quantitative Review", desc: "Solve 21 quant questions in 45 minutes relying purely on estimation and algebra." },
      { phase: "Phase 4: Official GMAC Adaptive Practice Exams", title: "Full 2-Hour 15-Minute Adaptive Test Review", priority: "high", durationHours: 3.0, sourceRef: "Official GMAC Starter Kit", desc: "Practice test question review and score targeting 655+ (90th percentile)." }
    ]
  },
  "CA": {
    name: "CA (Chartered Accountancy - ICAI Foundation / Inter)",
    badge: "Commerce & Accounting",
    category: "Finance / Professional",
    subjects: ["Accounting & Advanced Accounting", "Corporate & Other Laws", "Taxation (Direct & GST)", "Cost & Management Accounting", "Auditing & Ethics"],
    defaultFocus: "ICAI Study Modules, Practical Problem Formats & Legal Sections",
    channels: ["CA Rachana Ranade", "Swapnil Patni Classes", "Ednovate", "CA Wallah", "Aldine CA"],
    modules: [
      { phase: "Phase 1: ICAI Study Material Comprehensive Coverage", title: "Line-by-Line Study Module Illustrations & Accounting Concepts", priority: "high", durationHours: 4.0, sourceRef: "ICAI Official Study Material (icai.org)", desc: "Solve all module illustrations, ledger postings, adjustments, and accounting standard disclosures." },
      { phase: "Phase 2: Legal Case Laws, Sections & Tax Provisions", title: "Companies Act Sections, Case Law Quotations & Tax Slabs", priority: "high", durationHours: 3.5, sourceRef: "MCA Regulations & Income Tax Act", desc: "Memorize legal section numbers, provisions, exceptions, and GST input tax credit rules." },
      { phase: "Phase 3: Revision Test Papers (RTP) & Mock Test Papers (MTP)", title: "Current Attempt RTP & Past 3 Attempts MTP Solving", priority: "high", durationHours: 4.0, sourceRef: "ICAI BoS Knowledge Portal", desc: "Solve official RTP questions and amend answers to match the latest ICAI statutory updates." },
      { phase: "Phase 4: 100-Mark 3-Hour Descriptive Exam Presentation", title: "Step-by-Step Working Notes & Neat Financial Presentation", priority: "high", durationHours: 3.5, sourceRef: "ICAI Suggested Answers Benchmark", desc: "Practice time management (1.8 minutes per mark) and write full explanatory working notes." }
    ]
  },
  "CFA": {
    name: "CFA (Chartered Financial Analyst - Level 1/2/3)",
    badge: "Global Investment",
    category: "Finance / Professional",
    subjects: ["Ethical & Professional Standards", "Quantitative Methods", "Economics", "Financial Statement Analysis", "Corporate Issuers", "Equity & Fixed Income", "Derivatives & Alternatives", "Portfolio Management"],
    defaultFocus: "Ethics Mastery, Financial Reporting Adjustments & Asset Valuation",
    channels: ["Mark Meldrum", "AnalystPrep", "Fintree", "Kaplan Schweser"],
    modules: [
      { phase: "Phase 1: Financial Statement Analysis & Corporate Finance", title: "Income Statements, Balance Sheets, Cash Flows & Inventories", priority: "high", durationHours: 4.0, sourceRef: "CFA Institute Candidate Body of Knowledge", desc: "Master US GAAP vs IFRS differences, revenue recognition, and financial ratio analysis." },
      { phase: "Phase 2: Equity, Fixed Income & Derivatives Valuation", title: "DCF Models, Bond Yields, Duration, Convexity & Options", priority: "high", durationHours: 4.0, sourceRef: "CFA Institute Curriculum", desc: "Calculate bond pricing, forward contracts, binomial option trees, and CAPM returns with financial calculator." },
      { phase: "Phase 3: Ethical and Professional Standards (Strict Passing Component)", title: "Code of Ethics, 7 Standards of Professional Conduct Caselets", priority: "high", durationHours: 3.0, sourceRef: "CFA Institute Standards of Practice Handbook", desc: "Solve 100+ nuanced ethics scenario questions to ensure scoring above 70% threshold." },
      { phase: "Phase 4: CFA Institute Official Mock Exams", title: "Two 135-Minute Session CBT Simulations", priority: "high", durationHours: 4.5, sourceRef: "CFA Institute Learning Ecosystem", desc: "Complete official mock exams targeting >75% to beat the Minimum Passing Score (MPS)." }
    ]
  },
  "CUET": {
    name: "CUET (Central Universities Entrance Test - UG)",
    badge: "University Entrance",
    category: "Undergraduate",
    subjects: ["Language", "Domain Subjects (Class 12)", "General Test"],
    defaultFocus: "Class 12 NCERT Line-by-Line & General Knowledge / Logic",
    channels: ["CUET Wallah", "Unacademy CUET", "Adda247 CUET", "Malviya Academy"],
    modules: [
      { phase: "Phase 1: Class 12 NCERT Domain Chapter Deep-Dive", title: "NCERT Line-by-Line Revision for Selected Domain", priority: "high", durationHours: 3.0, sourceRef: "NTA CUET Domain Syllabus (exams.nta.ac.in)", desc: "100% focus on Class 12 NCERT syllabus. Memorize all box items, timelines, and summaries." },
      { phase: "Phase 2: General Test & Language (English/Hindi) Prep", title: "Reading Passages, Quantitative Reasoning & Static GK", priority: "high", durationHours: 3.0, sourceRef: "NTA General Test Guidelines", desc: "Practice 50 MCQs daily covering mental ability, numerical reasoning, and vocabulary." },
      { phase: "Phase 3: Shift-Wise Past Year Questions & NTA Mock Papers", title: "Previous Years CUET Shift Question Drilling", priority: "high", durationHours: 3.5, sourceRef: "NTA Official Mock Portal", desc: "Practice solving 40 out of 50 questions within 45 minutes for each domain subject." }
    ]
  },
  "NDA": {
    name: "NDA & NA (National Defence Academy - Army/Navy/Air Force)",
    badge: "Defence Entrance",
    category: "Defence",
    subjects: ["Mathematics (300 Marks)", "General Ability Test - GAT (600 Marks)"],
    defaultFocus: "Speed Math (Class 11/12) + English & General Science / History",
    channels: ["Defence Wallah", "Centurion Defence Academy", "Unacademy Defence", "Arpit Choudhary"],
    modules: [
      { phase: "Phase 1: NDA Mathematics Formula Sheet & Short Tricks", title: "Trigonometry, Calculus, Vectors & Matrices (120 Questions)", priority: "high", durationHours: 3.5, sourceRef: "UPSC NDA Mathematics Syllabus", desc: "Master calculation shortcuts to attempt 70+ math questions in 150 minutes." },
      { phase: "Phase 2: GAT English & General Science Fundamentals", title: "50 English MCQs + Physics/Chemistry/Biology Basics", priority: "high", durationHours: 3.5, sourceRef: "UPSC NDA GAT Blueprint", desc: "Revise NCERT 9-10 science concepts, grammar spotting errors, and idioms." },
      { phase: "Phase 3: History, Geography, Polity & Current Defence News", title: "Indian Freedom Struggle, Physical Geography & Defence Tech", priority: "medium", durationHours: 3.0, sourceRef: "UPSC Examination Guidelines", desc: "Focus on national defense exercises, maps, physical geography, and freedom movement." },
      { phase: "Phase 4: Full NDA Mock Test & Negative Marking Management", title: "Full 900-Mark Dual Paper Simulation", priority: "high", durationHours: 4.0, sourceRef: "UPSC Official Past Papers Archive", desc: "Complete Paper 1 (Maths: 2.5 Hrs) and Paper 2 (GAT: 2.5 Hrs) back-to-back." }
    ]
  },
  "AFCAT": {
    name: "AFCAT & CDS (Air Force & Combined Defence Services)",
    badge: "Officer Defence",
    category: "Defence",
    subjects: ["General Awareness", "Verbal Ability in English", "Numerical Ability", "Reasoning and Military Aptitude"],
    defaultFocus: "Spatial Reasoning, Military History, Speed Arithmetic & Current Affairs",
    channels: ["Defence Wallah", "SSB Crack Exams", "CDS Journey", "Centurion Academy"],
    modules: [
      { phase: "Phase 1: Military Aptitude & Spatial Visual Reasoning", title: "Rotated Blocks, Embedded Figures, Venn Diagrams & Patterns", priority: "high", durationHours: 3.0, sourceRef: "IAF C-DAC AFCAT Blueprint", desc: "Master non-verbal reasoning and 3D figure rotation puzzles." },
      { phase: "Phase 2: Numerical Ability & English Vocabulary", title: "Speed Arithmetic, Spotting Errors & Idioms/Phrases", priority: "high", durationHours: 3.0, sourceRef: "AFCAT Examination Syllabus", desc: "Practice 20 speed arithmetic problems and 30 English grammar questions." },
      { phase: "Phase 3: Defence Affairs, Geography & History", title: "IAF Aircraft Fleet, Missiles, Battles & World Geography", priority: "medium", durationHours: 2.5, sourceRef: "Ministry of Defence Releases", desc: "Revise defense equipment, missile ranges, operations, and sports awards." },
      { phase: "Phase 4: 100-Question 2-Hour CBT Mock Test", title: "Full 300-Mark AFCAT Timed Simulation", priority: "high", durationHours: 3.0, sourceRef: "C-DAC Official AFCAT Portal", desc: "Target 210+ score for flying and technical branches." }
    ]
  },
  "CLAT": {
    name: "CLAT (Common Law Admission Test - NLUs)",
    badge: "Law Entrance",
    category: "Law",
    subjects: ["Legal Reasoning", "Logical Reasoning", "Reading Comprehension", "Current Affairs & GK", "Quantitative Techniques"],
    defaultFocus: "Passage Comprehension, Critical Thinking & Legal Principles",
    channels: ["LegalEdge", "Law Wallah", "Unacademy CLAT", "12 Minutes to CLAT"],
    modules: [
      { phase: "Phase 1: Passage-Based Critical Reading & Speed Training", title: "Speed Reading 450-Word Editorial & Legal Excerpts", priority: "high", durationHours: 3.5, sourceRef: "Consortium of National Law Universities", desc: "Practice extracting premises, conclusions, and author tone from dense passages within 2.5 minutes." },
      { phase: "Phase 2: Legal Reasoning & Landmark Case Laws", title: "Constitutional Law, Torts, Contracts & Criminal Law", priority: "high", durationHours: 3.5, sourceRef: "Supreme Court Precedents & Legal Statutes", desc: "Apply legal principles strictly to factual situations without bringing outside bias." },
      { phase: "Phase 3: Current Affairs & Static Legal GK Compilations", title: "Monthly Legal Current Affairs & National Law Reforms", priority: "high", durationHours: 3.0, sourceRef: "PRS India & Judicial News Portals", desc: "Revise major bills, international treaties, and constitutional amendments." },
      { phase: "Phase 4: 120-Question Timed Mock Simulation (120 Mins)", title: "Full-Length Passage-Based CBT Simulation", priority: "high", durationHours: 3.0, sourceRef: "CLAT Consortium Practice Tests", desc: "Simulate exact 120-minute examination targeting 100+ attempts with 90%+ accuracy." }
    ]
  },
  "UGC-NET": {
    name: "UGC NET & CSIR NET (Assistant Professor & JRF)",
    badge: "Lectureship & Research",
    category: "Teaching / Research",
    subjects: ["Paper 1: Teaching & Research Aptitude", "Paper 2: Subject Specialization", "Higher Education System & Environment"],
    defaultFocus: "Pedagogy, Research Methodology, Data Interpretation & Subject Deep Dive",
    channels: ["Kumar Bharat", "Navclasses", "Arpita Karwa", "BYJU'S UGC NET", "Unacademy UGC NET"],
    modules: [
      { phase: "Phase 1: Paper 1 Research Methodology & Teaching Aptitude", title: "Hypothesis Testing, Sampling, Pedagogy & ICT Tools", priority: "high", durationHours: 3.5, sourceRef: "UGC NET Official Syllabus (ugcnet.nta.ac.in)", desc: "Master research ethics, qualitative vs quantitative analysis, Bloom's taxonomy, and MOOCs." },
      { phase: "Phase 2: Higher Education Governance & People and Environment", title: "NEP 2020, Regulatory Bodies, Climate Protocols & Pollution", priority: "high", durationHours: 3.0, sourceRef: "Ministry of Education & UGC Framework", desc: "Study National Education Policy 2020, sustainable development goals, and renewable energy." },
      { phase: "Phase 3: Paper 2 Subject Specialization Deep Dive", title: "Postgraduate Subject Core Theories & Landmark Thinkers", priority: "high", durationHours: 4.0, sourceRef: "UGC Subject Syllabus Specifications", desc: "Solve 100 domain questions covering advanced master's level concepts." },
      { phase: "Phase 4: Combined 150-Question 3-Hour CBT Mock Test", title: "Paper 1 (50 Qs) + Paper 2 (100 Qs) Marathon Drill", priority: "high", durationHours: 3.5, sourceRef: "NTA Official Mock Test Interface", desc: "Target 200+ out of 300 to clear Junior Research Fellowship (JRF) cutoff." }
    ]
  },
  "SAT": {
    name: "Digital SAT (College Admissions - US & Global)",
    badge: "Global Undergrad",
    category: "Study Abroad",
    subjects: ["Reading & Writing (Module 1 & 2)", "Math (Module 1 & 2)"],
    defaultFocus: "Adaptive Section Strategy, Desmos Calculator Mastery & Grammar Rules",
    channels: ["Khan Academy SAT", "Scalar Learning", "PrepPros SAT", "John Chung Math"],
    modules: [
      { phase: "Phase 1: Digital SAT Grammar Conventions & Rhetoric", title: "Punctuation, Transitions, Command of Evidence & Synthesis", priority: "high", durationHours: 3.0, sourceRef: "Official College Board SAT Suite", desc: "Master standard English punctuation (semicolons, em-dashes, commas) and passage rhetoric." },
      { phase: "Phase 2: Desmos Graphing Calculator & Hard Math Concepts", title: "Quadratic Systems, Geometry, Trig & Exponential Models", priority: "high", durationHours: 3.5, sourceRef: "College Board Official Math Blueprint", desc: "Master built-in Desmos graphing calculator tricks to solve complex algebra in under 30 seconds." },
      { phase: "Phase 3: Official Bluebook Full Adaptive Practice Tests", title: "Full Digital Adaptive Test (Module 1 Easy/Med & Module 2 Hard)", priority: "high", durationHours: 3.0, sourceRef: "College Board Bluebook App Practice", desc: "Complete official adaptive practice exams to unlock high-difficulty Module 2." }
    ]
  },
  "GRE": {
    name: "GRE General Test (Graduate & PhD Admissions)",
    badge: "Global Graduate",
    category: "Study Abroad",
    subjects: ["Quantitative Reasoning", "Verbal Reasoning", "Analytical Writing"],
    defaultFocus: "High-Frequency Vocabulary, Text Completion & Data Interpretation",
    channels: ["GregMat", "Magoosh GRE", "Manhattan Prep", "Tested Tutor"],
    modules: [
      { phase: "Phase 1: 1000 High-Frequency GRE Words & Sentence Equivalence", title: "Etymology, Context Clues & Pair Word Strategies", priority: "high", durationHours: 3.0, sourceRef: "ETS Official GRE Verbal Framework", desc: "Memorize root words, secondary word definitions, and pair-word elimination techniques." },
      { phase: "Phase 2: Quantitative Comparison & Hard Quant Concepts", title: "Number Properties, Permutations, Probability & Coordinate Geometry", priority: "high", durationHours: 3.5, sourceRef: "ETS Official Math Review Guide", desc: "Practice quantitative comparison traps, picking smart numbers, and virtual calculator usage." },
      { phase: "Phase 3: ETS PowerPrep Full-Length Simulation & Issue Essay", title: "Timed Shorter GRE 1-Hour 58-Minute Full Test", priority: "high", durationHours: 3.0, sourceRef: "ETS PowerPrep Official Portal", desc: "Simulate test conditions and review score scaling across 170 Quant / 170 Verbal." }
    ]
  },
  "IELTS": {
    name: "IELTS Academic & General (English Proficiency - Band 8+)",
    badge: "Language Test",
    category: "Study Abroad / Immigration",
    subjects: ["Listening (40 Questions)", "Reading (Academic 3 Passages)", "Writing (Task 1 & Task 2 Essay)", "Speaking (Part 1, 2 Cue Card, 3)"],
    defaultFocus: "Band 8+ Descriptors, Collocations, Flow & Paraphrasing",
    channels: ["IELTS Advantage", "E2 IELTS", "Fastrack IELTS", "Liz IELTS", "Keith Speaking Academy"],
    modules: [
      { phase: "Phase 1: Listening & Reading Speed Strategies", title: "Multiple Choice, Map Labeling, True/False/Not Given Mastery", priority: "high", durationHours: 3.0, sourceRef: "Cambridge IELTS Official Practice", desc: "Practice audio note-taking, skimming & scanning dense academic texts under 60 minutes." },
      { phase: "Phase 2: Writing Task 1 (Data/Charts) & Task 2 (Opinion/Discussion Essay)", title: "Coherence, Cohesion, Lexical Resource & Grammatical Accuracy", priority: "high", durationHours: 3.5, sourceRef: "Official IELTS Band Descriptors (ielts.org)", desc: "Write 250-word essays with structured paragraphs, clear thesis, and complex sentence structures." },
      { phase: "Phase 3: Speaking Fluency & Cue Card Part 2 Drills", title: "2-Minute Monologues, Idiomatic Language & Pronunciation", priority: "high", durationHours: 2.5, sourceRef: "British Council & IDP Guidelines", desc: "Record 10 cue card topics without hesitation, using signpost words and natural tone." },
      { phase: "Phase 4: Full Timed 4-Module Mock Exam & Band Evaluation", title: "Full 2.5-Hour Academic Examination Simulation", priority: "high", durationHours: 3.0, sourceRef: "Cambridge English Assessment", desc: "Score listening and reading against raw band tables aiming for 35+ correct (Band 8.0+)." }
    ]
  },
  "TOEFL": {
    name: "TOEFL iBT (English for University Admissions)",
    badge: "Language Test",
    category: "Study Abroad",
    subjects: ["Reading", "Listening", "Speaking (Integrated)", "Writing for Academic Discussion"],
    defaultFocus: "Campus Audio Conversations, Academic Lectures & Rapid Typing",
    channels: ["TST Prep", "Notefull TOEFL", "TOEFL Resources", "E2 TOEFL"],
    modules: [
      { phase: "Phase 1: Academic Reading & Campus Listening", title: "Inference, Vocabulary in Context & Lecture Note-Taking", priority: "high", durationHours: 3.0, sourceRef: "ETS TOEFL Official Guide", desc: "Practice fast note-taking on university biology, history, and geology lectures." },
      { phase: "Phase 2: Integrated Speaking (Campus Situations & Academic Concepts)", title: "Synthesizing Reading + Listening into 60-Second Responses", priority: "high", durationHours: 3.0, sourceRef: "ETS Speaking Scoring Rubrics", desc: "Master speech templates for summarizing conflicting viewpoints in under 60 seconds." },
      { phase: "Phase 3: Writing for Academic Discussion & Integrated Essay", title: "10-Minute Academic Discussion Post Writing", priority: "high", durationHours: 2.5, sourceRef: "New TOEFL iBT Writing Format", desc: "Express clear arguments with personal examples in 100+ words within 10 minutes." },
      { phase: "Phase 4: Full ETS Official Practice Test (Under 2 Hours)", title: "Full Shorter TOEFL iBT Timed Test", priority: "high", durationHours: 2.5, sourceRef: "ETS Official Test Portal", desc: "Review section scores aiming for 105+ out of 120." }
    ]
  },
  "BOARD": {
    name: "Class 10 / 12 Board Exams (CBSE & State Boards)",
    badge: "Board Exams",
    category: "School Boards",
    subjects: ["Science", "Mathematics", "Social Studies", "Language"],
    defaultFocus: "NCERT Solutions, Derivations & Step-by-Step Writing",
    channels: ["Vedantu 9&10", "Learnohub", "Apni Kaksha", "Physics Wallah Foundation", "Next Toppers"],
    modules: [
      { phase: "Phase 1: NCERT Comprehensive Textbook Coverage", title: "Textbook Theory, In-Text Questions & Solved Examples", priority: "high", durationHours: 3.0, sourceRef: "NCERT / CBSE Curriculum (cbse.gov.in)", desc: "Read every section thoroughly and solve all in-text questions and back exercises." },
      { phase: "Phase 2: Derivations, Definitions & Diagram Practice", title: "Descriptive Derivations & Step-by-Step Answer Writing", priority: "high", durationHours: 3.0, sourceRef: "CBSE Official Marking Scheme Guidelines", desc: "Practice complete step-by-step mathematical proofs, physics derivations, and biological diagrams." },
      { phase: "Phase 3: Official Sample Question Papers (SQP)", title: "CBSE Official Sample Papers & Blueprint Practice", priority: "high", durationHours: 3.5, sourceRef: "CBSE Academic Sample Question Papers", desc: "Solve the official sample question paper strictly according to the latest marking scheme." },
      { phase: "Phase 4: Previous 5 Years Board Papers", title: "Board Examination Past 5 Years Papers", priority: "medium", durationHours: 3.0, sourceRef: "CBSE Examination Archive", desc: "Practice 3-hour answer presentation, neat handwriting, and time division for descriptive questions." }
    ]
  },
  "GENERAL": {
    name: "General / University / Academic Study",
    badge: "Academic Study",
    category: "General",
    subjects: ["General Academic"],
    defaultFocus: "Foundations, Applications & Project Review",
    channels: ["3Blue1Brown", "CrashCourse", "MIT OpenCourseWare", "Khan Academy", "Veritasium"],
    modules: [
      { phase: "Phase 1: Conceptual Foundations & Terminology", title: "Core Theoretical Principles & Terminology", priority: "high", durationHours: 2.5, sourceRef: "OpenStax & Peer-Reviewed Academic Repositories", desc: "Understand foundational definitions, historical context, and core principles." },
      { phase: "Phase 2: In-Depth Mechanisms & Theoretical Models", title: "Detailed Theoretical Frameworks & Formulas", priority: "high", durationHours: 3.0, sourceRef: "Open Educational Resources (OER)", desc: "Deep dive into formulas, theorems, and mechanisms." },
      { phase: "Phase 3: Practical Application & Case Studies", title: "Hands-on Practice & Problem Sets", priority: "high", durationHours: 3.5, sourceRef: "Academic Practice Archives", desc: "Work on practical exercises, real-world case studies, and numerical applications." },
      { phase: "Phase 4: Synthesis & Final Self-Assessment", title: "Active Recall Synthesis & Mock Review", priority: "medium", durationHours: 2.5, sourceRef: "Verified Knowledge Base", desc: "Synthesize all concepts, review summary notes, and take a self-assessment quiz." }
    ]
  }
};

// ── Helper to calculate Phased Dates ───────────────────────────────────────────
function buildPhasedRoadmapWithDates(modules, startDateStr, endDateStr, topic, examName) {
  const startDate = new Date(startDateStr || new Date());
  const endDate = new Date(endDateStr || new Date(startDate.getTime() + (21 * 24 * 60 * 60 * 1000)));

  const totalDays = Math.max(1, Math.round((endDate - startDate) / (1000 * 60 * 60 * 24)));
  const stepDays = Math.max(1, Math.floor(totalDays / modules.length));

  return modules.map((m, index) => {
    const targetDate = new Date(startDate);
    targetDate.setDate(startDate.getDate() + (index * stepDays));
    const isoDate = targetDate.toISOString().split('T')[0];

    const formattedDate = targetDate.toLocaleDateString("en-US", {
      weekday: "short",
      year: "numeric",
      month: "short",
      day: "numeric"
    });

    return {
      stepNumber: index + 1,
      phase: m.phase || `Phase ${index + 1}`,
      title: `${m.title} — ${topic}`,
      scheduled_date: isoDate,
      display_date: formattedDate,
      priority: m.priority || "high",
      durationHours: m.durationHours || 3.0,
      sourceRef: m.sourceRef || "NCERT / Official Syllabus Guidelines",
      desc: m.desc || `Study and master ${topic} according to ${examName} guidelines.`,
      targetDeliverable: `Complete ${m.phase} objectives & practice sets for ${topic}.`
    };
  });
}

// ── Helper for YouTube Video Recommendations ─────────────────────────────────
function getYouTubeRecommendations(topic, examType = "GENERAL") {
  const exam = EXAM_PROFILES[examType] || EXAM_PROFILES["GENERAL"];
  const examName = examType !== "GENERAL" ? examType : "";
  const queryPrefix = examName ? `${examName} ${topic}` : topic;

  return [
    {
      title: `${examName ? '[' + examName + '] ' : ''}${topic} Complete One-Shot Marathon`,
      channel: exam.channels[0] || "Top Educator Channel",
      tag: "Full Revision One-Shot",
      duration: "2 - 4 Hours",
      searchQuery: `${queryPrefix} one shot full chapter`,
      url: `https://www.youtube.com/results?search_query=${encodeURIComponent(queryPrefix + " one shot full chapter")}`
    },
    {
      title: `Top 50 Most Repeated PYQs & Tricky Questions: ${topic}`,
      channel: exam.channels[1] || "Master Faculty",
      tag: "PYQs & Question Solving",
      duration: "1.5 Hours",
      searchQuery: `${queryPrefix} previous year questions pyq solving`,
      url: `https://www.youtube.com/results?search_query=${encodeURIComponent(queryPrefix + " previous year questions pyq")}`
    },
    {
      title: `${topic} Concepts, Derivations & Formula Revision`,
      channel: exam.channels[2] || "Academic Channel",
      tag: "Concept & Formulas",
      duration: "45 Mins",
      searchQuery: `${queryPrefix} formula sheet short notes revision`,
      url: `https://www.youtube.com/results?search_query=${encodeURIComponent(queryPrefix + " formula sheet short notes revision")}`
    },
    {
      title: `${topic} Animated Concept Visualizer & Intuitive Explanation`,
      channel: exam.channels[3] || "Visual Learning Hub",
      tag: "Deep Intuition",
      duration: "30 Mins",
      searchQuery: `${topic} visualization animation conceptual explanation`,
      url: `https://www.youtube.com/results?search_query=${encodeURIComponent(topic + " visualization animation conceptual explanation")}`
    }
  ];
}

// ── GET /api/edu/info?topic=...&exam=...&start_date=...&end_date=... ──────────
router.get("/info", async (req, res) => {
  const topic = req.query.topic?.trim();
  const examType = (req.query.exam?.trim() || "GENERAL").toUpperCase();
  const startDateStr = req.query.start_date || new Date().toISOString().split('T')[0];
  
  const defaultEnd = new Date(startDateStr);
  defaultEnd.setDate(defaultEnd.getDate() + 30);
  const endDateStr = req.query.end_date || defaultEnd.toISOString().split('T')[0];

  if (!topic) {
    return res.status(400).json({ error: "Query parameter 'topic' is required." });
  }

  try {
    const encoded = encodeURIComponent(topic.replace(/\s+/g, "_"));
    let eduData = null;
    try {
      const wikiRes = await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${encoded}`, {
        headers: {
          "User-Agent": "StudySync-EduHub/1.0 (academic study planner; contact@studysync.local)"
        }
      });
      if (wikiRes.ok) {
        eduData = await wikiRes.json();
      }
    } catch (_) {}

    const examProfile = EXAM_PROFILES[examType] || EXAM_PROFILES["GENERAL"];
    const trustedSources = TRUSTED_SOURCES[examType] || TRUSTED_SOURCES["GENERAL"];

    const rawModules = examProfile.modules || EXAM_PROFILES["GENERAL"].modules;
    const phasedRoadmap = buildPhasedRoadmapWithDates(rawModules, startDateStr, endDateStr, topic, examProfile.name);
    const youtubeRecommendations = getYouTubeRecommendations(topic, examType);

    res.json({
      topic: eduData?.title || topic,
      examType: examType,
      examName: examProfile.name,
      examBadge: examProfile.badge,
      description: eduData?.description || `Educational Roadmap tailored for ${examProfile.name}`,
      summary: eduData?.extract || `Comprehensive educational curriculum and roadmap for ${topic}, structured specifically for ${examProfile.name}.`,
      thumbnail: eduData?.thumbnail?.source || null,
      sourceUrl: eduData?.content_urls?.desktop?.page || `https://en.wikipedia.org/wiki/${encoded}`,
      trustedSources: trustedSources,
      roadmapTimeline: phasedRoadmap,
      youtubeVideos: youtubeRecommendations,
      suggestedGoals: [
        `Achieve 90%+ accuracy in ${examType !== 'GENERAL' ? examType : 'exam'} questions on ${topic}`,
        `Complete all ${phasedRoadmap.length} scheduled phases on time with mistake log revision`,
        `Solve 100+ past year questions (PYQs) and master high-yield formula sheets`
      ]
    });
  } catch (err) {
    console.error("Edu info fetch error:", err);
    res.status(500).json({ error: "Failed to fetch educational info: " + err.message });
  }
});

// ── POST /api/edu/generate-plan ──────────────────────────────────────────────
router.post("/generate-plan", auth, async (req, res) => {
  const db = req.app.get("db");
  const { topic, subject, goal, start_date, end_date, level, exam, custom_focus } = req.body;

  if (!topic || !start_date || !end_date) {
    return res.status(400).json({ error: "topic, start_date, and end_date are required." });
  }

  const examType = (exam || "GENERAL").toUpperCase();
  const examProfile = EXAM_PROFILES[examType] || EXAM_PROFILES["GENERAL"];
  const subjectName = subject || topic;
  const userGoal = goal || `Target 90%+ in ${examType} — Master ${topic} (${level || 'All Levels'})`;

  try {
    const encoded = encodeURIComponent(topic.replace(/\s+/g, "_"));
    let summaryText = "";
    try {
      const wikiRes = await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${encoded}`, {
        headers: { "User-Agent": "StudySync-EduHub/1.0" }
      });
      if (wikiRes.ok) {
        const wikiData = await wikiRes.json();
        summaryText = wikiData.extract ? wikiData.extract.substring(0, 250) + "..." : "";
      }
    } catch (_) {}

    const planTitle = `[${examType}] ${topic} Complete Roadmap`;
    const planResult = db.run(
      `INSERT INTO study_plans (user_id, title, subject, goal, start_date, end_date)
       VALUES (?, ?, ?, ?, ?, ?)`,
      req.user.id, planTitle, subjectName, `${userGoal}${summaryText ? ` | ${summaryText}` : ''}`, start_date, end_date
    );

    const planId = planResult.lastInsertRowid;

    const rawModules = examProfile.modules || EXAM_PROFILES["GENERAL"].modules;
    const phasedRoadmap = buildPhasedRoadmapWithDates(rawModules, start_date, end_date, topic, examProfile.name);

    if (custom_focus && custom_focus.trim()) {
      const focusDate = new Date(start_date);
      focusDate.setDate(focusDate.getDate() + Math.floor(phasedRoadmap.length / 2) * 4);
      phasedRoadmap.splice(2, 0, {
        stepNumber: 3,
        phase: "Custom Focus Drill",
        title: `Custom Focus: ${custom_focus.trim()} — ${topic}`,
        scheduled_date: focusDate.toISOString().split('T')[0],
        display_date: focusDate.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", year: "numeric" }),
        priority: "high",
        durationHours: 3.5,
        sourceRef: "Student Custom Priority Goal",
        desc: `Intensive targeted study and problem drilling on: ${custom_focus.trim()}.`,
        targetDeliverable: `Master ${custom_focus.trim()} problem types.`
      });
    }

    const createdTasks = [];
    phasedRoadmap.forEach((item) => {
      const tRes = db.run(
        `INSERT INTO tasks (plan_id, user_id, title, description, scheduled_date, priority, status)
         VALUES (?, ?, ?, ?, ?, ?, 'pending')`,
        planId, req.user.id, item.title, `${item.phase} | ${item.desc} (Ref: ${item.sourceRef})`, item.scheduled_date, item.priority || "high"
      );

      const taskRow = db.get("SELECT * FROM tasks WHERE id = ?", tRes.lastInsertRowid);
      createdTasks.push(taskRow);
    });

    const createdPlan = db.get("SELECT * FROM study_plans WHERE id = ?", planId);
    const ytVideos = getYouTubeRecommendations(topic, examType);
    const trustedSources = TRUSTED_SOURCES[examType] || TRUSTED_SOURCES["GENERAL"];

    res.status(201).json({
      success: true,
      message: `Roadmap with scheduled dates generated and saved for ${examProfile.name}!`,
      plan: createdPlan,
      tasks: createdTasks,
      roadmapTimeline: phasedRoadmap,
      trustedSources: trustedSources,
      youtubeVideos: ytVideos
    });
  } catch (err) {
    console.error("Generate plan error:", err);
    res.status(500).json({ error: "Failed to generate study plan: " + err.message });
  }
});

module.exports = router;
