const express = require("express");
const auth    = require("../middleware/auth");

const router = express.Router();
router.use(auth);

// ── GET /api/plans/tasks/all ───────────────────────────────────────────────────
// Returns all tasks across all user plans with plan title, subject & progress score
router.get("/tasks/all", (req, res) => {
  const db = req.app.get("db");
  const tasks = db.all(
    `SELECT t.*, sp.title as plan_title, sp.subject as plan_subject, p.score, p.notes, p.logged_at
     FROM tasks t
     JOIN study_plans sp ON t.plan_id = sp.id
     LEFT JOIN progress p ON t.id = p.task_id
     WHERE t.user_id = ?
     ORDER BY t.status DESC, t.scheduled_date ASC`,
    req.user.id
  );
  res.json({ tasks });
});

// ── GET /api/plans ─────────────────────────────────────────────────────────────
router.get("/", (req, res) => {
  const db = req.app.get("db");
  const plans = db.all(
    "SELECT * FROM study_plans WHERE user_id = ? ORDER BY created_at DESC",
    req.user.id
  );
  res.json({ plans });
});

// ── GET /api/plans/:id ─────────────────────────────────────────────────────────
router.get("/:id", (req, res) => {
  const db = req.app.get("db");
  const plan = db.get(
    "SELECT * FROM study_plans WHERE id = ? AND user_id = ?",
    req.params.id, req.user.id
  );
  if (!plan) return res.status(404).json({ error: "Study plan not found." });

  const tasks = db.all(
    `SELECT t.*, p.score, p.notes, p.logged_at
     FROM tasks t
     LEFT JOIN progress p ON t.id = p.task_id
     WHERE t.plan_id = ?
     ORDER BY t.scheduled_date ASC`,
    plan.id
  );
  res.json({ plan, tasks });
});

// ── POST /api/plans ────────────────────────────────────────────────────────────
router.post("/", (req, res) => {
  const db = req.app.get("db");
  const { title, subject, goal, start_date, end_date } = req.body;

  if (!title || !subject || !start_date || !end_date) {
    return res.status(400).json({
      error: "title, subject, start_date, and end_date are required.",
    });
  }

  const result = db.run(
    `INSERT INTO study_plans (user_id, title, subject, goal, start_date, end_date)
     VALUES (?, ?, ?, ?, ?, ?)`,
    req.user.id, title, subject, goal || null, start_date, end_date
  );

  const plan = db.get("SELECT * FROM study_plans WHERE id = ?", result.lastInsertRowid);
  res.status(201).json({ message: "Study plan created.", plan });
});

// ── PUT /api/plans/:id ─────────────────────────────────────────────────────────
router.put("/:id", (req, res) => {
  const db = req.app.get("db");
  const plan = db.get(
    "SELECT * FROM study_plans WHERE id = ? AND user_id = ?",
    req.params.id, req.user.id
  );
  if (!plan) return res.status(404).json({ error: "Study plan not found." });

  const { title, subject, goal, start_date, end_date, status } = req.body;

  db.run(
    `UPDATE study_plans
     SET title = ?, subject = ?, goal = ?, start_date = ?, end_date = ?, status = ?
     WHERE id = ?`,
    title      || plan.title,
    subject    || plan.subject,
    goal       !== undefined ? goal : plan.goal,
    start_date || plan.start_date,
    end_date   || plan.end_date,
    status     || plan.status,
    plan.id
  );

  const updated = db.get("SELECT * FROM study_plans WHERE id = ?", plan.id);
  res.json({ message: "Study plan updated.", plan: updated });
});

// ── DELETE /api/plans/:id ──────────────────────────────────────────────────────
router.delete("/:id", (req, res) => {
  const db = req.app.get("db");
  const plan = db.get(
    "SELECT * FROM study_plans WHERE id = ? AND user_id = ?",
    req.params.id, req.user.id
  );
  if (!plan) return res.status(404).json({ error: "Study plan not found." });

  db.run("DELETE FROM tasks WHERE plan_id = ?", plan.id);
  db.run("DELETE FROM study_plans WHERE id = ?", plan.id);
  res.json({ message: "Study plan deleted." });
});

// ── POST /api/plans/:id/tasks ──────────────────────────────────────────────────
router.post("/:id/tasks", (req, res) => {
  const db = req.app.get("db");
  const plan = db.get(
    "SELECT * FROM study_plans WHERE id = ? AND user_id = ?",
    req.params.id, req.user.id
  );
  if (!plan) return res.status(404).json({ error: "Study plan not found." });

  const { title, description, scheduled_date, priority } = req.body;
  if (!title || !scheduled_date) {
    return res.status(400).json({ error: "title and scheduled_date are required." });
  }

  const result = db.run(
    `INSERT INTO tasks (plan_id, user_id, title, description, scheduled_date, priority, status)
     VALUES (?, ?, ?, ?, ?, ?, 'pending')`,
    plan.id, req.user.id, title, description || null, scheduled_date, priority || "medium"
  );

  const task = db.get("SELECT * FROM tasks WHERE id = ?", result.lastInsertRowid);
  res.status(201).json({ message: "Task added.", task });
});

// ── PATCH /api/plans/tasks/:taskId/toggle ──────────────────────────────────────
router.patch("/tasks/:taskId/toggle", (req, res) => {
  const db = req.app.get("db");
  const task = db.get(
    "SELECT * FROM tasks WHERE id = ? AND user_id = ?",
    req.params.taskId, req.user.id
  );
  if (!task) return res.status(404).json({ error: "Task not found." });

  const nextStatus = task.status === "completed" ? "pending" : "completed";
  db.run("UPDATE tasks SET status = ? WHERE id = ?", nextStatus, task.id);

  // If marking as completed and no progress entry exists, create a default score entry (100)
  if (nextStatus === "completed") {
    const existing = db.get("SELECT * FROM progress WHERE task_id = ?", task.id);
    if (!existing) {
      db.run("INSERT INTO progress (user_id, task_id, score, notes) VALUES (?, ?, ?, ?)",
        req.user.id, task.id, 85, "Completed task module");
    }
  }

  const updated = db.get("SELECT * FROM tasks WHERE id = ?", task.id);
  res.json({ message: `Task marked as ${nextStatus}.`, task: updated });
});

// ── PATCH /api/plans/tasks/:taskId ────────────────────────────────────────────
router.patch("/tasks/:taskId", (req, res) => {
  const db = req.app.get("db");
  const task = db.get(
    "SELECT * FROM tasks WHERE id = ? AND user_id = ?",
    req.params.taskId, req.user.id
  );
  if (!task) return res.status(404).json({ error: "Task not found." });

  const { status, priority, title, description, scheduled_date } = req.body;

  db.run(
    `UPDATE tasks
     SET status = ?, priority = ?, title = ?, description = ?, scheduled_date = ?
     WHERE id = ?`,
    status         || task.status,
    priority       || task.priority,
    title          || task.title,
    description    !== undefined ? description : task.description,
    scheduled_date || task.scheduled_date,
    task.id
  );

  const updated = db.get("SELECT * FROM tasks WHERE id = ?", task.id);
  res.json({ message: "Task updated.", task: updated });
});

module.exports = router;
