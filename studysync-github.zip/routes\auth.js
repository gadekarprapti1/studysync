const express = require("express");
const bcrypt  = require("bcryptjs");
const jwt     = require("jsonwebtoken");
const auth    = require("../middleware/auth");

const router = express.Router();

// ── POST /api/auth/register ────────────────────────────────────────────────────
router.post("/register", (req, res) => {
  const db = req.app.get("db");
  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ error: "Name, email, and password are required." });
  }

  const existing = db.get("SELECT id FROM users WHERE email = ?", email);
  if (existing) {
    return res.status(409).json({ error: "An account with this email already exists." });
  }

  const hashed = bcrypt.hashSync(password, 10);
  const result = db.run(
    "INSERT INTO users (name, email, password) VALUES (?, ?, ?)",
    name, email, hashed
  );

  const token = jwt.sign(
    { id: result.lastInsertRowid, email },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || "7d" }
  );

  res.status(201).json({
    message: "Account created successfully.",
    token,
    user: { id: result.lastInsertRowid, name, email },
  });
});

// ── POST /api/auth/login ───────────────────────────────────────────────────────
router.post("/login", (req, res) => {
  const db = req.app.get("db");
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: "Email and password are required." });
  }

  const user = db.get("SELECT * FROM users WHERE email = ?", email);
  if (!user) {
    return res.status(401).json({ error: "Invalid email or password." });
  }

  const valid = bcrypt.compareSync(password, user.password);
  if (!valid) {
    return res.status(401).json({ error: "Invalid email or password." });
  }

  const token = jwt.sign(
    { id: user.id, email: user.email },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || "7d" }
  );

  res.json({
    message: "Login successful.",
    token,
    user: { id: user.id, name: user.name, email: user.email },
  });
});

// ── GET /api/auth/me ───────────────────────────────────────────────────────────
router.get("/me", auth, (req, res) => {
  const db = req.app.get("db");
  const user = db.get(
    "SELECT id, name, email, created_at FROM users WHERE id = ?",
    req.user.id
  );
  if (!user) return res.status(404).json({ error: "User not found." });
  res.json({ user });
});

module.exports = router;
