/**
 * db.js — sql.js wrapper that mimics a synchronous better-sqlite3 interface.
 * sql.js is pure JavaScript (no native compilation needed).
 * The database is persisted to studysync.db on disk after every write.
 */

const initSqlJs = require("sql.js");
const fs = require("fs");
const path = require("path");

const DB_PATH = path.join(__dirname, "../studysync.db");

// We export a promise that resolves to the db helper.
// server.js awaits this before starting the HTTP server.
module.exports = initSqlJs().then((SQL) => {
  // Load existing DB from disk, or create a new one
  let db;
  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
  }

  // ── Persist helper ──────────────────────────────────────────────────────────
  function persist() {
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  }

  // ── Create tables ───────────────────────────────────────────────────────────
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      name       TEXT    NOT NULL,
      email      TEXT    NOT NULL UNIQUE,
      password   TEXT    NOT NULL,
      created_at TEXT    DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS study_plans (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id    INTEGER NOT NULL,
      title      TEXT    NOT NULL,
      subject    TEXT    NOT NULL,
      goal       TEXT,
      start_date TEXT    NOT NULL,
      end_date   TEXT    NOT NULL,
      status     TEXT    DEFAULT 'active',
      created_at TEXT    DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS tasks (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      plan_id        INTEGER NOT NULL,
      user_id        INTEGER NOT NULL,
      title          TEXT    NOT NULL,
      description    TEXT,
      scheduled_date TEXT    NOT NULL,
      priority       TEXT    DEFAULT 'medium',
      status         TEXT    DEFAULT 'pending',
      created_at     TEXT    DEFAULT (datetime('now')),
      FOREIGN KEY (plan_id) REFERENCES study_plans(id),
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS progress (
      id        INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id   INTEGER NOT NULL,
      task_id   INTEGER NOT NULL,
      score     INTEGER DEFAULT 0,
      notes     TEXT,
      logged_at TEXT    DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id),
      FOREIGN KEY (task_id) REFERENCES tasks(id)
    );

    CREATE TABLE IF NOT EXISTS user_subjects (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id      INTEGER NOT NULL,
      name         TEXT    NOT NULL,
      target_exam  TEXT    DEFAULT 'GENERAL',
      target_score INTEGER DEFAULT 90,
      color        TEXT    DEFAULT '#8b5cf6',
      created_at   TEXT    DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id)
    );
  `);
  persist();

  // ── Helpers that mimic better-sqlite3's prepare().get/all/run ──────────────

  /**
   * Returns the first matching row as a plain object, or undefined.
   */
  function get(sql, ...params) {
    const stmt = db.prepare(sql);
    stmt.bind(params);
    if (stmt.step()) {
      const row = stmt.getAsObject();
      stmt.free();
      return row;
    }
    stmt.free();
    return undefined;
  }

  /**
   * Returns all matching rows as an array of plain objects.
   */
  function all(sql, ...params) {
    const rows = [];
    const stmt = db.prepare(sql);
    stmt.bind(params);
    while (stmt.step()) {
      rows.push(stmt.getAsObject());
    }
    stmt.free();
    return rows;
  }

  /**
   * Executes an INSERT / UPDATE / DELETE and returns { lastInsertRowid, changes }.
   * Persists the DB to disk after every write.
   */
  function run(sql, ...params) {
    db.run(sql, params);
    const lastInsertRowid = db.exec("SELECT last_insert_rowid()")[0]?.values[0][0] ?? null;
    const changes = db.exec("SELECT changes()")[0]?.values[0][0] ?? 0;
    persist();
    return { lastInsertRowid, changes };
  }

  return { get, all, run };
});
