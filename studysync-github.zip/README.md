# 📚 StudySync - AI Adaptive Study Planner (Backend)

Backend REST API for **StudySync**, an intelligent and adaptive study planning & educational roadmap platform built with Node.js, Express, and SQL database storage.

---

## ✨ Features

- 🔐 **Authentication & Security**: Secure user registration & login using JWT (JSON Web Tokens) and bcrypt password hashing.
- 🎯 **Exam & Education Roadmaps (`/api/edu`)**:
  - Pre-curated high-yield syllabi and roadmaps for major exams (JEE Main & Advanced, NEET-UG, UPSC CSE, GATE, CBSE Class 10/12, GRE, Coding/DSA, and General studies).
  - Phased study schedules with calculated task dates.
  - Curated YouTube channels and trusted reference source recommendations.
  - Diagnostic readiness quizzes with custom score computation and topic breakdown.
- 📅 **Study Plans & Tasks (`/api/plans`)**:
  - Full CRUD operations for custom study plans and milestones.
  - Sub-task management, priority tagging, and completion tracking.
- 📊 **Progress & Analytics (`/api/progress`)**:
  - Progress metrics, completion percentages, study streaks, and activity history.
- 📖 **Subject Directory (`/api/subjects`)**:
  - Subject and module catalog organization.
- 🧪 **Built-in Interactive Tester**:
  - Lightweight single-page frontend test suite served directly at `/` (`test.html`).

---

## 🚀 Quick Start

### 1. Prerequisites
- [Node.js](https://nodejs.org/) (v16 or higher recommended)
- [npm](https://www.npmjs.com/)

### 2. Installation
Clone the repository and install the dependencies:
```bash
git clone https://github.com/your-username/studysync-backend.git
cd studysync-backend
npm install
```

### 3. Configure Environment Variables
Copy `.env.example` to create your `.env` file:
```bash
cp .env.example .env
```
Edit `.env` as needed:
```env
PORT=5000
JWT_SECRET=your_super_secret_jwt_key
JWT_EXPIRES_IN=7d
CLIENT_ORIGIN=http://127.0.0.1:5500
```

### 4. Run the Server
```bash
# Start server
npm start

# Or with nodemon (development mode)
npm run dev
```

The server will be live at `http://localhost:5000`.

---

## 📡 API Endpoints Overview

| Method | Endpoint | Description | Auth Required |
|---|---|---|:---:|
| `GET` | `/api/health` | Service health status | ❌ |
| `POST` | `/api/auth/register` | Register a new user | ❌ |
| `POST` | `/api/auth/login` | Login and obtain JWT token | ❌ |
| `GET` | `/api/auth/me` | Fetch authenticated profile | ✅ |
| `GET` | `/api/edu/exams` | List supported exam syllabi | ❌ |
| `GET` | `/api/edu/exams/:key` | Get detailed curriculum & sources | ❌ |
| `POST` | `/api/edu/generate-plan` | Generate phased study roadmap | ✅ |
| `POST` | `/api/edu/quiz/evaluate` | Evaluate diagnostic quiz | ✅ |
| `GET` | `/api/plans` | List user study plans | ✅ |
| `POST` | `/api/plans` | Create a study plan | ✅ |
| `PATCH` | `/api/plans/tasks/:id/status` | Update task status | ✅ |
| `GET` | `/api/progress/summary` | Get user study progress & stats | ✅ |
| `GET` | `/api/subjects` | List subjects and categories | ✅ |

---

## 🧪 Testing the API
Open your browser and navigate to:
```
http://localhost:5000/
```
This loads the built-in testing dashboard (`test.html`) to authenticate, test endpoints, generate plans, and verify responses interactively.

---

## 📁 Project Structure

```
studysync-backend/
├── config/             # Database initialization & helper wrapper
├── middleware/         # JWT authentication & verification middleware
├── routes/             # Express API route handlers
│   ├── auth.js         # Authentication routes
│   ├── edu.js          # Exam syllabi & roadmap generator
│   ├── progress.js     # Progress tracking routes
│   ├── studyPlans.js   # Study plan & task management routes
│   └── subjects.js     # Subject catalog routes
├── .env.example        # Template configuration file
├── .gitignore          # Git exclusion rules
├── package.json        # Dependencies & scripts
├── README.md           # Documentation
├── server.js           # Express app entry point
└── test.html           # Interactive frontend tester
```

---

## 📄 License
ISC License. Feel free to use and modify for your projects!
