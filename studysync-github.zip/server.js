require("dotenv").config();
const express = require("express");
const cors = require("cors");

const path = require("path");

const app  = express();
const PORT = process.env.PORT || 5000;

// ── Middleware ─────────────────────────────────────────────────────────────────
app.use(cors({
  origin: "*",
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE"],
  allowedHeaders: ["Content-Type", "Authorization"],
}));
app.use(express.json());

// ── Serve Frontend Tester UI ───────────────────────────────────────────────────
app.get("/", (_req, res) => {
  res.sendFile(path.join(__dirname, "test.html"));
});
app.use(express.static(__dirname));

// ── Health check (no DB needed) ────────────────────────────────────────────────
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", app: "StudySync API", version: "1.0.0" });
});

// ── Boot: wait for DB then mount routes ───────────────────────────────────────
require("./config/db").then((db) => {
  // Attach db to app so routes can access it via req.app.get("db")
  app.set("db", db);

  app.use("/api/auth",     require("./routes/auth"));
  app.use("/api/plans",    require("./routes/studyPlans"));
  app.use("/api/progress", require("./routes/progress"));
  app.use("/api/edu",      require("./routes/edu"));
  app.use("/api/subjects", require("./routes/subjects"));

  // 404 handler
  app.use((_req, res) => {
    res.status(404).json({ error: "Route not found." });
  });

  // Global error handler
  app.use((err, _req, res, _next) => {
    console.error("[Error]", err.message);
    res.status(500).json({ error: "Internal server error." });
  });

  app.listen(PORT, () => {
    console.log(`StudySync API running on http://localhost:${PORT}`);
  });
}).catch((err) => {
  console.error("Failed to initialise database:", err.message);
  process.exit(1);
});
